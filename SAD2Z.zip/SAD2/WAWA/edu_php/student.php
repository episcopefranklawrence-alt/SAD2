<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>EDUGRAM — Academic Writing & Submission System</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="../edu.css" />
  
  <link href="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.snow.min.css" rel="stylesheet"/>
</head>
<body class="student-page">

  
  <div id="auth-screen" class="screen active">
    <div class="auth-page-bg">

      
      <div class="auth-card-wrap">

        
        <div id="login-view" class="auth-card-view active">
          <div class="auth-card">

            
            <div class="auth-avatar-ring">
              <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" width="40" height="40">
                <circle cx="20" cy="15" r="8" fill="var(--navy)" opacity=".18"/>
                <circle cx="20" cy="14" r="7" fill="var(--navy)"/>
                <path d="M4 36c0-8.837 7.163-14 16-14s16 5.163 16 14" fill="var(--navy)" opacity=".85"/>
              </svg>
            </div>

            
            <div class="auth-card-brand">
              <svg width="22" height="22" viewBox="0 0 40 40" fill="none">
                <rect width="40" height="40" rx="9" fill="var(--navy)"/>
                <path d="M8 26L18 10L28 26H8Z" fill="var(--gold)" opacity="0.95"/>
                <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.95"/>
              </svg>
              <span class="auth-card-brand-name">EDUGRAM</span>
            </div>

            <div class="auth-card-header">
              <h2>Welcome back</h2>
              <p>Sign in to your account to continue</p>
            </div>

            <div class="field-group">
              <label for="login-email">Email Address</label>
              <input type="email" id="login-email" placeholder="you@institution.edu" autocomplete="email" />
            </div>

            <div class="field-group">
              <label for="login-password">Password</label>
              <div class="password-wrap">
                <input type="password" id="login-password" placeholder="••••••••" autocomplete="current-password" />
                <button type="button" class="pw-toggle" data-target="login-password" aria-label="Show or hide password">
                  <svg class="eye-show" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>
                  <svg class="eye-hide" viewBox="0 0 20 20" fill="currentColor" style="display:none"><path fill-rule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clip-rule="evenodd"/><path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.064 7 9.542 7 .847 0 1.669-.105 2.454-.303z"/></svg>
                </button>
              </div>
            </div>

            <div id="login-error" class="form-error hidden"></div>

            <button class="btn-primary auth-submit-btn" id="login-btn">
              <span class="btn-label">Login</span>
              <span class="btn-spinner hidden"></span>
            </button>

            <div class="auth-card-links">
              <a href="#" id="go-register-link">Create Account</a>
              <a href="#" id="forgot-password-link">Forgot Password?</a>
            </div>

          </div>
        </div>

        
        <div id="register-view" class="auth-card-view">
          <div class="auth-card">

            <div class="auth-card-brand">
              <svg width="22" height="22" viewBox="0 0 40 40" fill="none">
                <rect width="40" height="40" rx="9" fill="var(--navy)"/>
                <path d="M8 26L18 10L28 26H8Z" fill="var(--gold)" opacity="0.95"/>
                <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.95"/>
              </svg>
              <span class="auth-card-brand-name">EDUGRAM</span>
            </div>

            <div class="auth-card-header">
              <h2>Create Account</h2>
              <p>Join EDUGRAM — fill in your details below</p>
            </div>

            <div class="field-row">
              <div class="field-group">
                <label>First Name</label>
                <input type="text" id="reg-first" placeholder="First" autocomplete="given-name" />
              </div>
              <div class="field-group">
                <label>Middle Name (optional)</label>
                <input type="text" id="reg-middle" placeholder="Middle" autocomplete="additional-name" />
              </div>
              <div class="field-group">
                <label>Last Name</label>
                <input type="text" id="reg-last" placeholder="Last" autocomplete="family-name" />
              </div>
            </div>

            <div class="field-group">
              <label>Institutional Email</label>
              <input type="email" id="reg-email" placeholder="you@institution.edu" autocomplete="email" />
            </div>

            <div class="field-group">
              <label>Phone (optional)</label>
              <input type="tel" id="reg-phone" placeholder="Phone number" autocomplete="tel" />
            </div>

            <div class="field-group">
              <label>Student / Employee ID</label>
              <input type="text" id="reg-id" placeholder="e.g. 2024-00123" />
            </div>

            <div class="field-group">
              <label>Course (optional)</label>
              <select id="reg-course"><option value="">Select course</option></select>
              <label for="reg-major">Major</label>
              <select id="reg-major" disabled><option value="">Select major</option></select>
              <div class="field-row reg-year-section-inputs">
                <div class="field-group"><label for="reg-year">Year</label><input id="reg-year" type="number" min="1" max="6" step="1" inputmode="numeric" placeholder="1–6" /></div>
                <div class="field-group"><label for="reg-section">Section</label><input id="reg-section" type="text" maxlength="16" placeholder="e.g. 1 WMT" /></div>
              </div>
              <small class="academic-input-hint">Example: Year 4 and Section 1 WMT appear as 4-1 WMT.</small>
              <output id="reg-academic-output" class="academic-record-output" aria-live="polite">Your year and section will appear here.</output>
              <div id="reg-class-error" class="form-error hidden" role="alert"></div>
            </div>

            <div class="field-group">
              <label>Password</label>
              <div class="password-wrap">
                <input type="password" id="reg-password" placeholder="At least 8 characters, including uppercase, lowercase, and a number." autocomplete="new-password" />
                <button type="button" class="pw-toggle" data-target="reg-password" aria-label="Show or hide password">
                  <svg class="eye-show" viewBox="0 0 20 20" fill="currentColor"><path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/><path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/></svg>
                  <svg class="eye-hide" viewBox="0 0 20 20" fill="currentColor" style="display:none"><path fill-rule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clip-rule="evenodd"/><path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.064 7 9.542 7 .847 0 1.669-.105 2.454-.303z"/></svg>
                </button>
              </div>
              <small id="reg-password-strength" aria-live="polite">Strength: Weak</small>
              <small>At least 8 characters, including uppercase, lowercase, and a number. A symbol is optional and may improve strength.</small>
            </div>

            <div class="field-group">
              <label for="reg-role-select">I am a…</label>
              <div class="role-dropdown-wrap">
                <select id="reg-role-select" name="role" class="role-dropdown">
                  <option value="" disabled selected>Select your role</option>
                  <option value="student">Student</option>
                  <option value="teacher">Teacher</option>
                  <option value="admin">Admin</option>
                </select>
                <span class="role-dropdown-arrow">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>
                </span>
              </div>
            </div>

            <div id="register-error" class="form-error hidden"></div>
            <div id="register-success" class="form-success hidden"></div>

            <button class="btn-primary auth-submit-btn" id="register-btn">
              <span class="btn-label">Create Account</span>
              <span class="btn-spinner hidden"></span>
            </button>

            <div class="auth-card-links auth-card-links--center">
              <a href="#" id="go-login-link">Already have an account? Sign in</a>
            </div>

          </div>
        </div>

        
        <div id="forgot-view" class="auth-card-view">
          <div class="auth-card">

            <div class="auth-card-brand">
              <svg width="22" height="22" viewBox="0 0 40 40" fill="none">
                <rect width="40" height="40" rx="9" fill="var(--navy)"/>
                <path d="M8 26L18 10L28 26H8Z" fill="var(--gold)" opacity="0.95"/>
                <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.95"/>
              </svg>
              <span class="auth-card-brand-name">EDUGRAM</span>
            </div>

            <div class="auth-card-header">
              <h2>Reset Password</h2>
              <p>Enter your email and we'll send reset instructions</p>
            </div>

            <div class="field-group">
              <label for="forgot-email">Email Address</label>
              <input type="email" id="forgot-email" placeholder="you@institution.edu" autocomplete="email" />
            </div>

            <div id="forgot-error" class="form-error hidden"></div>
            <div id="forgot-success" class="form-success hidden"></div>

            <button class="btn-primary auth-submit-btn" id="forgot-btn">
              <span class="btn-label">Send Reset Link</span>
              <span class="btn-spinner hidden"></span>
            </button>

            <div class="auth-card-links auth-card-links--center">
              <a href="#" id="go-login-from-forgot">Back to Sign In</a>
            </div>

          </div>
        </div>

        <p class="auth-page-footer">© 2026 EDUGRAM · Academic Writing &amp; Submission System</p>
      </div>

    </div>
  </div>

  
    
    <aside class="sidebar" id="student-sidebar">
      <div class="sidebar-brand">
        <svg width="28" height="28" viewBox="0 0 36 36" fill="none">
          <rect width="36" height="36" rx="10" fill="#1a3a5c"/>
          <path d="M8 26L18 10L28 26H8Z" fill="#c9a84c" opacity="0.9"/>
          <path d="M13 26L18 17L23 26H13Z" fill="white" opacity="0.9"/>
        </svg>
        <span>EDUGRAM</span>
      </div>
      <nav class="sidebar-nav">
        <a href="#" class="nav-item active" data-panel="s-overview">
          <svg viewBox="0 0 20 20" fill="currentColor"><path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/></svg>
          Overview
        </a>
        <a href="#" class="nav-item" data-panel="s-assignments">
          <svg viewBox="0 0 20 20" fill="currentColor"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/><path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd"/></svg>
          Assignments
        </a>
        <a href="#" class="nav-item" data-panel="s-editor">
          <svg viewBox="0 0 20 20" fill="currentColor"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"/></svg>
          Writing Editor
        </a>
        <a href="#" class="nav-item" data-panel="s-pdf-checker">
          <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M5 2a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7.828A2 2 0 0016.414 6L12 1.586A2 2 0 0010.586 1H5zm5 1.5V7a1 1 0 001 1h3.5L10 3.5zM6 11a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h4a1 1 0 100-2H7z" clip-rule="evenodd"/></svg>
          PDF Checker
        </a>
        <a href="#" class="nav-item" data-panel="s-history">
          <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/></svg>
          Submission History
        </a>
        <a href="#" class="nav-item" data-panel="s-feedback">
          <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z" clip-rule="evenodd"/></svg>
          Feedback
        </a>
        <a href="#" class="nav-item" data-panel="s-profile">
          <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/></svg>
          My Profile
        </a>
      </nav>
      <div class="sidebar-footer">
        <div class="user-info" id="student-user-info">
          <div class="user-avatar" id="student-avatar">S</div>
          <div class="user-details">
            <span class="user-name" id="student-name">Student</span>
            <span class="user-role">Student</span>
          </div>
        </div>
        <button class="logout-btn" id="student-logout">
          <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clip-rule="evenodd"/></svg>
        </button>
      </div>
    </aside>

    
    <main class="main-content" id="student-main">
      <div class="topbar">
        <div class="topbar-left">
          <button class="menu-toggle" id="student-menu-toggle" aria-label="Toggle navigation menu">
            <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clip-rule="evenodd"/></svg>
          </button>
          <h1 class="topbar-title" id="student-panel-title">Overview</h1>
        </div>
        <div class="topbar-right">
          <div class="lang-badge">🇬🇧 English</div>
          <div class="notification-btn" id="notif-toggle" aria-label="View notifications" role="button" tabindex="0">
            <svg viewBox="0 0 20 20" fill="currentColor"><path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z"/></svg>
            <span class="notif-dot" id="notif-indicator"></span>
          </div>
        </div>
      </div>

      
      <div class="panel active" id="s-overview">
        <div class="panel-content">
          <div class="welcome-banner">
            <div class="welcome-text">
              <h2>Good day, <span id="student-welcome-name">Student</span> 👋</h2>
              <p>You have <strong id="pending-count">2</strong> assignments pending and <strong id="feedback-count">1</strong> new feedback item.</p>
            </div>
            <div class="welcome-art">
              <svg width="120" height="80" viewBox="0 0 120 80">
                <ellipse cx="60" cy="70" rx="55" ry="8" fill="#1a3a5c" opacity="0.1"/>
                <rect x="25" y="15" width="70" height="55" rx="4" fill="#1a3a5c"/>
                <rect x="30" y="20" width="60" height="45" rx="2" fill="#f0f4f8"/>
                <rect x="35" y="27" width="40" height="3" rx="1" fill="#1a3a5c" opacity="0.4"/>
                <rect x="35" y="33" width="50" height="2" rx="1" fill="#1a3a5c" opacity="0.2"/>
                <rect x="35" y="38" width="45" height="2" rx="1" fill="#1a3a5c" opacity="0.2"/>
                <rect x="35" y="43" width="50" height="2" rx="1" fill="#1a3a5c" opacity="0.2"/>
                <circle cx="75" cy="28" r="12" fill="#c9a84c"/>
                <path d="M71 28l3 3 6-6" stroke="white" stroke-width="2" fill="none" stroke-linecap="round"/>
              </svg>
            </div>
          </div>

          <div class="stats-row">
            <div class="stat-card overview-stat-link" role="button" tabindex="0" data-overview-panel="s-assignments" data-overview-title="Assignments" data-overview-filter="all" aria-label="View all assignments">
              <div class="stat-icon blue"><svg viewBox="0 0 20 20" fill="currentColor"><path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/><path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5z" clip-rule="evenodd"/></svg></div>
              <div class="stat-info">
                <span class="stat-num" id="s-total-assignments">0</span>
                <span class="stat-label">Total Assignments</span>
              </div>
            </div>
            <div class="stat-card overview-stat-link" role="button" tabindex="0" data-overview-panel="s-assignments" data-overview-title="Assignments" data-overview-filter="submitted" aria-label="View submitted assignments">
              <div class="stat-icon gold"><svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg></div>
              <div class="stat-info">
                <span class="stat-num" id="s-submitted">0</span>
                <span class="stat-label">Submitted</span>
              </div>
            </div>
            <div class="stat-card overview-stat-link" role="button" tabindex="0" data-overview-panel="s-assignments" data-overview-title="Assignments" data-overview-filter="pending" aria-label="View pending assignments">
              <div class="stat-icon red"><svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clip-rule="evenodd"/></svg></div>
              <div class="stat-info">
                <span class="stat-num" id="s-pending">0</span>
                <span class="stat-label">Pending</span>
              </div>
            </div>
            <div class="stat-card overview-stat-link" role="button" tabindex="0" data-overview-panel="s-feedback" data-overview-title="Teacher Feedback" aria-label="View new feedback">
              <div class="stat-icon green"><svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7z" clip-rule="evenodd"/></svg></div>
              <div class="stat-info">
                <span class="stat-num" id="s-feedback-count">0</span>
                <span class="stat-label">New Feedback</span>
              </div>
            </div>
          </div>

          <div class="two-col">
            <div class="card">
              <div class="card-header">
                <h3>Upcoming Deadlines</h3>
                <a href="#" class="card-link s-nav-link" data-panel="s-assignments">View all</a>
              </div>
              <div class="deadline-list">
                <div class="deadline-item urgent">
                  <div class="deadline-dot"></div>
                  <div class="deadline-info">
                    <span class="deadline-title"></span>
                    <span class="deadline-sub"></span>
                  </div>
                  <span class="deadline-badge urgent"></span>
                </div>
                <div class="deadline-item">
                  <div class="deadline-dot"></div>
                  <div class="deadline-info">
                    <span class="deadline-title"></span>
                    <span class="deadline-sub"></span>
                  </div>
                  <span class="deadline-badge"></span>
                </div>
                <div class="deadline-item done">
                  <div class="deadline-dot"></div>
                  <div class="deadline-info">
                    <span class="deadline-title"></span>
                    <span class="deadline-sub"></span>
                  </div>
                  <span class="deadline-badge done"></span>
                </div>
              </div>
            </div>
            <div class="card">
              <div class="card-header">
                <h3>Recent Activity</h3>
                <a href="#" class="card-link s-nav-link" data-panel="s-history">View history</a>
              </div>
              <div class="activity-list">
                <div class="activity-item">
                  <div class="activity-icon edit"><svg viewBox="0 0 20 20" fill="currentColor"><path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"/></svg></div>
                  <div class="activity-text">
                    <span><em></em></span>
                    <time></time>
                  </div>
                </div>
                <div class="activity-item">
                  <div class="activity-icon submit"><svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 01-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L7.707 6.707a1 1 0 01-1.414 0z" clip-rule="evenodd"/></svg></div>
                  <div class="activity-text">
                    <span><em></em></span>
                    <time></time>
                  </div>
                </div>
                <div class="activity-item">
                  <div class="activity-icon feedback"><svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7z" clip-rule="evenodd"/></svg></div>
                  <div class="activity-text">
                    <span><em></em></span>
                    <time></time>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      
      <div class="panel" id="s-assignments">
        <div class="panel-content">
          <div class="section-header">
            <h2>My Assignments</h2>
            <div class="filter-row">
              <button class="filter-btn active" data-filter="all">All</button>
              <button class="filter-btn" data-filter="pending">Pending</button>
              <button class="filter-btn" data-filter="submitted">Submitted</button>
            </div>
          </div>
          <div class="student-record-table-wrap"><table class="student-record-table"><thead><tr><th>Assignment</th><th>Class</th><th>Due date</th><th>Words</th><th>Status</th><th>Action</th></tr></thead><tbody id="student-assignment-grid"></tbody></table></div>
          <div class="student-pagination" id="assignments-pagination" aria-label="Assignment pages"></div>
        </div>
      </div>

      
      <div class="panel" id="s-editor">
        <div class="panel-content editor-layout">
          <div class="editor-main">
            <div class="editor-toolbar">
              <div class="toolbar-left">
                <select id="assignment-select" class="toolbar-select">
                  <option value="">— Select Assignment —</option>
                </select>
              </div>
              <div class="toolbar-actions">
                <button class="toolbar-btn" id="check-writing-btn" title="Check Writing">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"/></svg>
                  Check Writing
                </button>
                <button type="button" class="toolbar-btn" id="gemini-improve-btn" title="Improve the selected passage with Gemini">
                  Improve with Gemini
                </button>
                <button class="toolbar-btn secondary" id="save-draft-btn">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M7.707 10.293a1 1 0 10-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 11.586V6h5a2 2 0 012 2v7a2 2 0 01-2 2H4a2 2 0 01-2-2V8a2 2 0 012-2h5v5.586l-1.293-1.293z"/></svg>
                  Save Draft
                </button>
                <button class="toolbar-btn primary" id="submit-assignment-btn">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 01-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L7.707 6.707a1 1 0 01-1.414 0z" clip-rule="evenodd"/></svg>
                  Submit
                </button>
              </div>
            </div>

            <div class="editor-meta" id="editor-meta">
              <div class="meta-item"><strong>Assignment:</strong> <span id="meta-title">—</span></div>
              <div class="meta-item"><strong>Due:</strong> <span id="meta-due">—</span></div>
              <div class="meta-item"><strong>Min. Words:</strong> <span id="meta-words">—</span></div>
            </div>

            <div class="writing-area-wrap">
              <div class="word-counter-bar">
                <span class="lang-indicator">🇬🇧 English (US)</span>
                <span id="word-count-display">0 words</span>
              </div>
              <div id="quill-editor" class="quill-editor-container"></div>
              <div id="submit-toast" class="submit-toast hidden">
                <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/></svg>
                Assignment submitted successfully!
              </div>
            </div>
          </div>

          
          <aside class="writing-assistant" role="complementary" aria-label="Writing assistant panel">
            <div class="assistant-header">
              <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clip-rule="evenodd"/></svg>
              Writing Assistant
              <span class="assistant-badge">EN</span>
            </div>

            <div class="assistant-score" id="assistant-score">
              <div class="score-ring">
                <svg viewBox="0 0 36 36" class="score-svg">
                  <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#e5e7eb" stroke-width="3"/>
                  <path id="score-arc" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="#c9a84c" stroke-width="3" stroke-dasharray="0, 100"/>
                </svg>
                <span class="score-num" id="score-num">—</span>
              </div>
              <span class="score-label">Writing Score</span>
            </div>

            <div class="assistant-sections">
              <div class="assistant-section" id="a-errors">
                <div class="section-title error-title">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/></svg>
                  Issues Found <span class="count-badge" id="error-count">0</span>
                </div>
                <div id="error-list" class="suggestion-list">
                  <p class="empty-hint">Click "Check Writing" to scan your text</p>
                </div>
              </div>

              <div class="assistant-section" id="a-suggestions">
                <div class="section-title suggest-title">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                  Style Suggestions
                </div>
                <div id="suggestion-list" class="suggestion-list">
                  <p class="empty-hint">Suggestions appear after checking</p>
                </div>
              </div>

              <div class="assistant-section">
                <div class="section-title">
                  <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/></svg>
                  Readability
                </div>
                <div id="readability-panel" class="readability-panel">
                  <div class="readability-item">
                    <span>Sentences</span><span id="r-sentences">—</span>
                  </div>
                  <div class="readability-item">
                    <span>Avg. Words/Sentence</span><span id="r-avg">—</span>
                  </div>
                  <div class="readability-item">
                    <span>Reading Level</span><span id="r-level">—</span>
                  </div>
                </div>
              </div>
            </div>

            <section class="gemini-suggestion hidden" id="gemini-suggestion-card" aria-live="polite">
              <div class="gemini-suggestion-heading">Gemini suggestion</div>
              <p class="gemini-suggestion-status" id="gemini-suggestion-status">Review the proposed revision before applying it.</p>
              <div class="gemini-suggestion-text" id="gemini-suggestion-text"></div>
              <div class="gemini-suggestion-actions">
                <button type="button" class="toolbar-btn primary" id="gemini-apply-btn">Replace selection</button>
                <button type="button" class="toolbar-btn secondary" id="gemini-dismiss-btn">Dismiss</button>
              </div>
            </section>

            
            <div class="ai-disclaimer" role="note">
              <svg viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/></svg>
              <span>AI suggestions are generated automatically and may not always be accurate. Please review all suggestions carefully before applying them.</span>
            </div>
          </aside>
        </div>
      </div>

      <div class="modal hidden" id="pre-submit-review-modal" role="dialog" aria-modal="true" aria-labelledby="pre-submit-title">
        <div class="modal-backdrop" id="pre-submit-backdrop"></div>
        <div class="modal-box pre-submit-modal-box">
          <div class="modal-header"><div><h3 id="pre-submit-title">Review your writing</h3><p>Check these suggestions before sending your submission.</p></div><button class="modal-close" id="pre-submit-close" type="button" aria-label="Close review">×</button></div>
          <div class="modal-body"><div class="pre-submit-summary" id="pre-submit-summary"></div><div class="pre-submit-issues" id="pre-submit-issues"></div></div>
          <div class="modal-footer"><button class="btn-secondary" id="pre-submit-edit-btn" type="button">Go back and edit</button><button class="btn-primary" id="pre-submit-confirm-btn" type="button">Submit anyway</button></div>
        </div>
      </div>

      
      <div class="panel" id="s-pdf-checker">
        <div class="panel-content">
          <div class="section-header">
            <div><h2>PDF Checker</h2><p>Check that a PDF opens, inspect its pages, and extract readable text.</p></div>
          </div>
          <div class="pdf-checker-layout">
            <section class="pdf-checker-card">
              <label class="pdf-dropzone" id="pdf-dropzone" for="pdf-file-input">
                <span class="pdf-drop-icon">PDF</span>
                <strong>Choose a PDF to check</strong>
                <span>or drag and drop it here · up to 20 MB</span>
                <input id="pdf-file-input" type="file" accept="application/pdf,.pdf" hidden>
              </label>
              <p class="pdf-checker-status" id="pdf-checker-status" role="status" aria-live="polite">Your file stays in this browser. It is not uploaded.</p>
              <div class="pdf-checker-details" id="pdf-checker-details" hidden></div>
              <div class="pdf-checker-actions">
                <button class="toolbar-btn" type="button" id="pdf-grammar-btn" disabled>Check grammar</button>
                <button class="btn-primary" type="button" id="pdf-open-editor-btn" disabled>Open extracted text in Writing Editor</button>
                <button class="toolbar-btn secondary" type="button" id="pdf-clear-btn" disabled>Clear</button>
              </div>
              <p class="pdf-checker-note">Grammar checking sends extracted text to the app’s LanguageTool service. Scanned PDFs need OCR, which is not available here.</p>
              <section class="pdf-grammar-results" id="pdf-grammar-results" aria-live="polite" hidden></section>
            </section>
            <section class="pdf-preview-card" aria-label="PDF first page preview">
              <h3>First page preview</h3>
              <div class="pdf-preview-frame" id="pdf-preview-frame"><span>Choose a PDF to preview its first page.</span><canvas id="pdf-preview-canvas" hidden></canvas></div>
            </section>
          </div>
        </div>
      </div>

      
      <div class="panel" id="s-history">
        <div class="panel-content">
          <div class="section-header">
            <h2>Submission History</h2>
          </div>
          <div class="history-table-wrap">
            <table class="history-table">
              <thead>
                <tr>
                  <th>Assignment</th>
                  <th>Submitted</th>
                  <th>Status</th>
                  <th>Grade</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody id="history-tbody">
                
              </tbody>
            </table>
          </div>
          <div class="student-pagination" id="history-pagination" aria-label="Submission history pages"></div>
        </div>
      </div>

      
      <div class="panel" id="s-feedback">
        <div class="panel-content">
          <div class="section-header">
            <h2>Teacher Feedback</h2>
          </div>
          <div class="student-record-table-wrap"><table class="student-record-table"><thead><tr><th>Assignment</th><th>Feedback</th><th>Grade</th><th>Action</th></tr></thead><tbody id="student-feedback-list">
            
          </tbody></table></div>
          <div class="student-pagination" id="feedback-pagination" aria-label="Feedback pages"></div>
        </div>
      </div>

      
      <div class="panel" id="s-profile">
        <div class="panel-content">
          <div class="section-header"><h2>My Profile</h2></div>
          <div class="card create-form-card" style="max-width:1800px;">
            <div class="teacher-profile-header">
              <div class="tp-avatar" id="sp-avatar-display">S</div>
              <div class="tp-info">
                <div class="tp-fullname" id="sp-fullname-display">—</div>
                <div class="tp-role-tag">Student</div>
              </div>
            </div>
            <div style="padding:1.5rem;display:flex;flex-direction:column;gap:1rem;">
              <div class="field-row">
                <div class="field-group"><label>First Name</label><input type="text" id="sp-first" /></div>
                <div class="field-group"><label>Middle Name</label><input type="text" id="sp-middle" /></div>
                <div class="field-group"><label>Last Name</label><input type="text" id="sp-last" /></div>
              </div>
              <div class="field-group">
                <label>Student ID</label>
                <input type="text" id="sp-id-input" disabled style="background:var(--gray-50);color:var(--gray-500);" />
              </div>
              <div class="field-row">
                <div class="field-group"><label for="sp-course">Course</label><select id="sp-course"></select></div>
                <div class="field-group"><label for="sp-major">Major</label><select id="sp-major" disabled></select></div>
                <div class="field-group"><label for="sp-year">Year</label><input id="sp-year" type="number" min="1" max="6" step="1" inputmode="numeric" placeholder="1–6" /></div>
                <div class="field-group"><label for="sp-section">Section</label><input id="sp-section" type="text" maxlength="16" placeholder="e.g. 1 WMT" /></div>
              </div>
              <output id="sp-academic-output" class="academic-record-output" aria-live="polite">Your saved year and section will appear here.</output>
              <div class="field-group">
                <label>New Password (leave blank to keep current)</label>
                <input type="password" id="sp-pass" placeholder="At least 8 characters, including uppercase, lowercase, and a number." />
                <small id="sp-password-strength" aria-live="polite">Strength: Weak</small>
                <small>At least 8 characters, including uppercase, lowercase, and a number. A symbol is optional and may improve strength.</small>
              </div>
              <div class="card"><h3>My Classes</h3><div id="student-classes-list" class="empty-hint">Loading...</div><div id="student-classes-error" class="form-error hidden" role="alert"></div></div>
              <div class="sp-activity-card" id="sp-activity-card">
                <div class="spa-title">My Academic Activity</div>
                <div class="spa-stats">
                  <div class="spa-stat"><span id="spa-submitted">0</span><span>Submitted</span></div>
                  <div class="spa-stat"><span id="spa-graded">0</span><span>Graded</span></div>
                  <div class="spa-stat"><span id="spa-pending">0</span><span>Pending</span></div>
                </div>
              </div>
              <button class="btn-primary" id="sp-save-btn">Save Changes</button>
              <div id="sp-toast" class="form-success hidden" style="margin-top:0;">Profile Updated!</div>
            </div>
          </div>
        </div>
      </div>

    </main>
  </div>

  
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/quill/1.3.7/quill.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
  <script src="../js/database.js"></script>
  <script src="../js/student.js"></script>
</body>
</html>
