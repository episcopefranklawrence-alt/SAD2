<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edugram OTP Verification</title>
</head>
<body>
    <h2>Enter Verification Code</h2>
    <form action="validate_otp.php" method="POST">
        <label for="email">Email Address:</label><br>
        <input type="email" id="email" name="email" required><br><br>

        <label for="otp_code">6-Digit OTP:</label><br>
        <input type="text" id="otp_code" name="otp_code" maxlength="6" required><br><br>

        <button type="submit">Verify Code</button>
    </form>
</body>
</html>