# EDUGRAM — Separated UI by Role

This folder contains the refactored EDUGRAM application with separated UI files for each user role (SuperAdmin, Admin, Teacher, Student).

## Project Structure

```
SAD_separated/
├── index.html              # Authentication page (shared by all roles)
├── student.html            # Student dashboard
├── teacher.html            # Teacher dashboard  
├── admin.html              # Admin dashboard
├── superadmin.html         # Super Admin dashboard
│
├── edu.css                 # Shared styles (unchanged)
├── shared.js               # Shared utilities & data models (from original edu.js)
├── auth.js                 # Authentication logic (login, registration)
├── student.js              # Student-specific dashboard logic
├── teacher.js              # Teacher-specific dashboard logic
├── admin.js                # Admin-specific dashboard logic
├── superadmin.js           # Super Admin-specific dashboard logic
│
├── server.js               # Express server
├── package.json            # Dependencies
└── README.md               # This file
```

## File Breakdown

### HTML Files

#### `index.html` - Authentication Page
- **Purpose**: Login and registration; password reset currently requires administrator assistance
- **Roles**: Accessible to all users before authentication
- **Key Features**:
  - Login form with email/password
  - Student-only public registration
  - Clear notice when password reset is not configured
  - Password visibility toggle
  - Form validation and error handling

#### `student.html` - Student Dashboard
- **Purpose**: Student learning and assignment management
- **Role Required**: `student`
- **Panels**:
  - Overview: Dashboard summary with statistics
  - Assignments: View assigned tasks
  - Writing Editor: Rich text editor with AI-powered assistance
  - Submission History: Track submitted work
  - Feedback: Receive teacher feedback
  - My Profile: Student profile management
- **Key Elements**:
  - Assignment tracking
  - Writing assistant with grammar/style checking
  - Submission management
  - Feedback notifications

#### `teacher.html` - Teacher Dashboard
- **Purpose**: Course and student management
- **Role Required**: `teacher`
- **Panels**:
  - Dashboard: Overview of classes and submissions
  - Create Assignment: Create and publish new assignments
  - Submissions: Review student submissions
  - My Assignments: Manage created assignments
  - My Profile: Teacher profile management
- **Key Elements**:
  - Assignment creation and management
  - Student submission review
  - Grading interface
  - Class management

#### `admin.html` - Admin Dashboard
- **Purpose**: User and system administration
- **Role Required**: `admin` or `super_admin`
- **Panels**:
  - Dashboard: System overview and statistics
  - User Management: Add/edit/delete users
  - Submissions: Monitor all submissions
  - System Settings: Configure system parameters
- **Key Elements**:
  - User CRUD operations
  - Role-based access control
  - System statistics
  - Activity monitoring

#### `superadmin.html` - Super Admin Dashboard
- **Purpose**: Full system administration
- **Role Required**: `super_admin`
- **Panels**: Same as admin with additional permissions
- **Key Differences**: Access to more advanced system controls

### JavaScript Files

#### `database.js` - Shared Client Utilities
Loads the authenticated dashboard data from the server. It does not persist
account or coursework changes to localStorage.
- **Data Management**:
  - Client state: USERS, ASSIGNMENTS, SUBMISSIONS, DRAFTS
  - NOTIFICATIONS system
- **Global State**: Shared application state

There are no default demo accounts. New public registrations receive the
student role. An authenticated administrator can assign staff roles; only a
super admin can assign the super-admin role.

#### `auth.js` - Authentication Logic
Handles all authentication flows:
- **Login**: Email/password verification with JWT token generation
- **Registration**: New user account creation as a student
- **Password Reset**: Not configured; the UI directs users to an administrator
- **Session Management**: JWT token storage in sessionStorage
- **Redirects**: Role-based navigation to appropriate dashboard

**Key Functions**:
- `handleLogin()`: Process login requests
- `handleRegister()`: Handle user registration
- `handleForgot()`: Password reset flow
- `showView()`: Switch between auth card views
- `setLoading()`: Update button loading state

#### `student.js` - Student Dashboard Logic
Manages student dashboard functionality:
- **Initialization**: Session check and authentication verification
- **UI Management**: Navigation, panel switching, sidebar toggle
- **Statistics**: Calculate and display assignment/submission stats
- **Navigation**: Switch between Overview, Assignments, Editor, History, Feedback, Profile panels
- **Session Management**: Logout and redirect

**Key Functions**:
- `initStudentDashboard()`: Initialize dashboard on page load
- `setupNavigation()`: Configure navigation event listeners
- `updateStudentStats()`: Calculate dashboard statistics
- `logout()`: Clear session and redirect to login

#### `teacher.js` - Teacher Dashboard Logic
Manages teacher dashboard functionality:
- **Initialization**: Teacher role verification
- **Dashboard**: Display class and submission statistics
- **Navigation**: Panel switching for different views
- **Statistics**: Track pending reviews, total students
- **Session Management**: Logout functionality

**Key Functions**:
- `initTeacherDashboard()`: Initialize dashboard
- `setupNavigation()`: Configure navigation
- `updateTeacherStats()`: Calculate teacher statistics
- `logout()`: Session cleanup

#### `admin.js` - Admin Dashboard Logic
Manages admin dashboard functionality:
- **Initialization**: Admin/SuperAdmin role verification
- **User Management**: View and manage system users
- **Statistics**: System-wide statistics (users, submissions, etc.)
- **Navigation**: Admin-specific panel switching
- **Session Management**: Logout functionality

**Key Functions**:
- `initAdminDashboard()`: Initialize admin dashboard
- `setupNavigation()`: Admin navigation setup
- `updateAdminStats()`: Calculate system statistics
- `logout()`: Session cleanup

#### `superadmin.js` - Super Admin Dashboard Logic
Extends admin functionality with additional permissions:
- All admin features
- Full system control
- Access to advanced settings
- System-wide configuration

### CSS File

#### `edu.css` - Shared Styles
Contains all styling for all roles:
- CSS variables for theming (--navy, --gold, --gray-*, etc.)
- Component styles (buttons, cards, forms, modals)
- Layout styles (sidebar, main content, topbar)
- Responsive design for mobile and desktop
- Role-specific styling variants

## Authentication Flow

```
1. User visits index.html (auth page)
   ↓
2. User enters credentials or registers
   ↓
3. Server checks credentials in MySQL or creates a student account in MySQL
   ↓
4. Server records the login attempt and signs a JWT
   ↓
5. JWT stored in sessionStorage; user role determines redirect:
   - student → student.html
   - teacher → teacher.html
   - admin → admin.html
   - super_admin → superadmin.html
   ↓
6. Dashboard code reads the JWT payload for display; protected API routes verify its signature
   ↓
7. Dashboard initializes with user data
   ↓
8. Logout clears session and returns to auth page
```

## Server Setup and Data Sources

Authentication and academic setup use only `edugram_login_db` through
`js/db.js`. The canonical `edugram_login_db.sql` defines the final 16-table
schema, including `courses`, `majors`, and `year_sections`; classes and
enrollments reference that hierarchy. There is no separate sections table.
The server never creates or alters tables.

```cmd
mysqldump -u root -p edugram_login_db > "C:\path\to\edugram_login_db-before-classes.sql"
```

Back up the existing database and verify `SELECT COUNT(*) FROM classes;`
returns zero before running the migration. The migration intentionally drops
the old class label/code columns and the free-text `users.section` values;
reassign users through Academic Setup afterward. Run it once from a Laragon
terminal opened in the project folder:

```cmd
mysql -u root -p edugram_login_db < academic_update.sql
```

Enter the Laragon MySQL password when prompted. If `mysql` is not on PATH,
run the same command from Laragon's MySQL `bin` folder. Review and back up
before running: MySQL DDL is not generally reversible. Configure the
connection in `.env` (do not commit that file):

```text
LOGIN_DB_HOST=127.0.0.1
LOGIN_DB_PORT=3306
LOGIN_DB_USER=root
LOGIN_DB_PASSWORD=
LOGIN_DB_NAME=edugram_login_db
JWT_SECRET=your_long_random_secret
BOOTSTRAP_ADMIN_EMAIL=admin@your-domain.edu
BOOTSTRAP_ADMIN_PASSWORD=use-a-unique-random-password-of-16-characters-or-more
```

`js/db.js` is the single MySQL connection module and requires
`LOGIN_DB_NAME=edugram_login_db`; it does not use `MYSQL_DATABASE`. Authentication
uses the lab's exact table/column names, including the `roles` relation,
`login_attempts`, `audit_logs`, `password_history`, `verification_codes`,
`user_sessions`, `linked_accounts`, and `two_factor_methods`; 2FA backup codes
belong in `two_factor_methods.backup_codes`, not a separate table. Assignments,
submissions, and drafts continue to use `database/edugram-db.json`. On first
startup, old JSON accounts are imported into the existing MySQL tables without
changing coursework; legacy student IDs in submissions and draft keys are
rewritten to MySQL `user_id` values, and the JSON user cache is removed.
Successful login upgrades legacy password hashes to bcrypt. Password changes
and resets store the new bcrypt hash in `password_history`.

Registration creates student accounts only. Passwords must be at least eight
characters and include uppercase, lowercase, and numeric characters; symbols
are optional. Registration and profile forms select an optional year and
section from the academic options API. Admins manage academic records, classes,
and memberships in the dashboard. The schema's required
`terms_accepted_at` timestamp is populated automatically; the UI does not ask
for terms acceptance. Admins promote staff accounts through the protected role
API, which resolves role IDs through the `roles` table.

For a provisioned schema with no user accounts, set `BOOTSTRAP_ADMIN_EMAIL` and
`BOOTSTRAP_ADMIN_PASSWORD` (at least 16 characters) in `.env` to create an
initial super admin. Without those values the server still starts with
student registration enabled, but staff-role management remains unavailable
until an administrator is provisioned. The server does not use bootstrap
values after an account exists. Bootstrap insertion uses the existing
`super_admin` row in `roles`.

## Session Management

- **Storage**: sessionStorage (temporary, cleared on browser close)
- **Key**: `edugram_jwt` - Contains encoded JWT token
- **Payload**: User ID, role, expiration time
- **Validation**: Each dashboard verifies JWT validity before displaying content

## Data Models

### User Object
```javascript
{
  id: "123",
  email: "user@domain.edu",
  phone: "+15551234567",
  role: "student|teacher|admin|super_admin",
  firstName: "First",
  lastName: "Last",
  studentId: "2026-00001",
  yearSectionId: "12"
}
```

Password hashes are server-only and are never included in the public user object.

### Assignment Object
```javascript
{
  id: "a_xxx",
  title: "Assignment Title",
  description: "Description",
  dueDate: "2026-06-30",
  class: "course - major - year/section - subject",
  createdBy: "teacher_id",
  forAll: false
}
```

### Submission Object
```javascript
{
  id: "sub_xxx",
  assignmentId: "a_xxx",
  studentId: "u_xxx",
  content: "Submission content",
  status: "draft|submitted|graded",
  submittedAt: "2026-06-29T10:00:00",
  grade: 85,
  feedback: "Great work!"
}
```

## Development Guide

### Adding New Features

1. **For all roles**: Add to `shared.js`
2. **For specific role**: Add to role-specific JS file (e.g., `student.js`)
3. **UI Elements**: Modify corresponding HTML file
4. **Styling**: Update `edu.css`

### Creating a New Dashboard Panel

1. Add HTML panel element to role's HTML file with `id="panel-id"`
2. Add navigation item with `data-panel="panel-id"`
3. In role-specific JS, add to `showPanel()` logic
4. Add title mapping in `setupNavigation()`

### Testing Authentication

```javascript
// Test through the login screen. Do not create or edit JWTs in the browser.
// The API server validates signatures on every protected request.
```

## Browser Compatibility

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance Notes

- Authentication users are stored in MySQL; coursework remains in JSON
- dashboard reads and writes are confirmed by the server; coursework remains in JSON
- Lightweight (~2.5MB with node_modules)
- Fast dashboard navigation

## Security Considerations

The server hashes passwords with bcrypt and signs JWTs with `JWT_SECRET`.
Protected API routes verify JWT signatures, public registrations are limited
to the student role, and submissions/drafts are scoped to the requesting
student. Use HTTPS and strong environment secrets when deploying outside a
local development environment. Automated account lockout, OTP, and email password recovery are not implemented.
The forgot-password UI reports that recovery is unavailable rather than claiming
that a reset was sent.

## Troubleshooting

### Dashboard won't load
- Check browser console for errors
- Verify JWT exists in sessionStorage
- Clear sessionStorage and re-login

### Buttons don't work
- Ensure shared.js loads before role-specific JS
- Check element IDs match in HTML and JS
- Verify CSS loads without errors

### Data not persisting
- Check that MySQL is running and `.env` points to `edugram_login_db`
- Check server logs for MySQL errors and browser messages for rejected saves
- Account, academic, class, and enrollment data is persisted in MySQL; assignments, submissions, and drafts are persisted in `database/edugram-db.json`

## File Size Reference

```
Original: edu.html (~65KB), edu.js (~112KB)
Separated:
- index.html (~20KB)
- student.html (~40KB) 
- teacher.html (~35KB)
- admin.html (~30KB)
- superadmin.html (~30KB)
- shared.js (~112KB)
- auth.js (~8KB)
- student.js (~5KB)
- teacher.js (~4KB)
- admin.js (~4KB)
- superadmin.js (~4KB)
```

## Migration Notes

If you have customizations to the original `edu.js`:

1. Add utility functions to `shared.js`
2. Add role-specific logic to corresponding JS file
3. Move DOM references to top of role file
4. Update event listeners to reference new structure
5. Test each role's dashboard independently

## Future Improvements

- [ ] Module bundler (Webpack/Rollup) for better separation
- [ ] Component library (Web Components or similar)
- [ ] State management (Redux/Zustand)
- [ ] API integration layer
- [ ] Build process for production optimization
- [ ] Unit and integration tests
- [ ] E2E testing (Cypress/Playwright)

## Support

For issues or questions about the separated structure:
1. Check browser console (F12) for errors
2. Verify all files are in same directory
3. Check network tab to ensure all files load
4. Review this README for common issues

---

**Last Updated**: June 2026  
**Version**: 1.0 (Separated UI)  
**Status**: Educational Demo
