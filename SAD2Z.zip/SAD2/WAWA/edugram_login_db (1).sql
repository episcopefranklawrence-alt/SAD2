-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2026 at 11:43 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edugram_login_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `assignment_id` bigint(20) UNSIGNED NOT NULL,
  `class_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `rubric` text DEFAULT NULL,
  `assignment_type` enum('essay','quiz','project','other') NOT NULL DEFAULT 'essay',
  `min_words` int(10) UNSIGNED NOT NULL DEFAULT 250,
  `due_date` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `event_type` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`log_id`, `user_id`, `event_type`, `description`, `ip_address`, `created_at`) VALUES
(1, 18, 'account_registered', 'Student account registered', '::1', '2026-10-21 18:39:36'),
(2, 18, 'login_success', 'User signed in', '::1', '2026-10-21 18:41:05'),
(3, 9, 'login_success', 'User signed in', '::1', '2026-10-21 18:47:19'),
(4, 9, 'login_success', 'User signed in', '::1', '2026-10-22 07:13:01'),
(5, 9, 'login_success', 'User signed in', '::1', '2026-10-22 07:37:53'),
(6, 9, 'login_success', 'User signed in', '::1', '2026-10-22 07:47:09'),
(7, 9, 'login_success', 'User signed in', '::1', '2026-10-22 07:47:44'),
(8, 9, 'login_success', 'User signed in', '::1', '2026-10-22 07:48:25'),
(9, 9, 'login_success', 'User signed in', '::1', '2026-10-23 04:56:25'),
(10, 9, 'profile_updated', 'User 9 updated profile for user 7', '::1', '2026-10-23 04:57:38'),
(11, 19, 'account_registered', 'Student account registered', '::1', '2026-10-23 04:58:50'),
(12, 9, 'login_success', 'User signed in', '::1', '2026-10-23 04:59:23'),
(13, 9, 'login_success', 'User signed in', '::1', '2026-10-23 04:59:51'),
(14, 9, 'password_reset', 'User 9 reset password for user 18', '::1', '2026-10-23 05:00:24'),
(15, 9, 'profile_updated', 'User 9 updated profile for user 18', '::1', '2026-10-23 05:00:26'),
(16, 18, 'login_success', 'User signed in', '::1', '2026-10-23 05:00:34'),
(17, 9, 'login_success', 'User signed in', '::1', '2026-10-23 05:05:17'),
(18, 9, 'profile_updated', 'User 9 updated profile for user 7', '::1', '2026-10-23 05:05:30'),
(19, 9, 'password_reset', 'User 9 reset password for user 7', '::1', '2026-10-23 05:05:40'),
(20, 9, 'profile_updated', 'User 9 updated profile for user 7', '::1', '2026-10-23 05:05:41'),
(21, 7, 'login_success', 'User signed in', '::1', '2026-10-23 05:05:53'),
(22, 9, 'login_success', 'User signed in', '::1', '2026-10-23 05:06:34'),
(23, 18, 'login_success', 'User signed in', '::1', '2026-10-23 05:07:56'),
(24, 9, 'login_success', 'User signed in', '::1', '2026-10-23 05:08:42'),
(25, 9, 'profile_updated', 'User 9 updated profile for user 19', '::1', '2026-10-23 05:09:12'),
(26, 9, 'role_changed', 'Changed user 19 role to teacher', '::1', '2026-10-23 05:09:12'),
(27, 9, 'login_success', 'User signed in', '::1', '2026-10-23 05:09:33'),
(28, 18, 'login_success', 'User signed in', '::1', '2026-10-23 05:11:01'),
(29, 9, 'login_success', 'User signed in', '::1', '2026-10-23 05:11:43'),
(30, 18, 'login_success', 'User signed in', '::1', '2026-10-23 05:32:03'),
(31, 9, 'login_success', 'User signed in', '::1', '2026-10-23 05:47:10'),
(32, 9, 'login_success', 'User signed in', '::1', '2026-10-23 05:54:17'),
(33, 9, 'login_success', 'User signed in', '::1', '2026-10-23 07:05:23'),
(34, 7, 'login_success', 'User signed in', '::1', '2026-10-23 07:35:50'),
(35, 9, 'login_success', 'User signed in', '::1', '2026-10-23 07:36:25'),
(36, 9, 'login_success', 'User signed in', '::1', '2026-10-23 09:16:25'),
(37, 9, 'login_success', 'User signed in', '::1', '2026-10-23 09:18:49'),
(38, 9, 'password_reset', 'User 9 reset password for user 8', '::1', '2026-10-23 09:19:08'),
(39, 9, 'profile_updated', 'User 9 updated profile for user 8', '::1', '2026-10-23 09:19:10'),
(40, 8, 'login_success', 'User signed in', '::1', '2026-10-23 09:19:17'),
(41, 9, 'login_success', 'User signed in', '::1', '2026-10-23 09:19:30'),
(42, 9, 'yearSection_created', 'Created year and section 4-1', '::1', '2026-10-23 09:21:20'),
(43, 9, 'yearSection_updated', 'Updated year and section 4-1 WMT', '::1', '2026-10-23 09:21:43'),
(44, 9, 'class_created', 'Created class 1: CC106', '::1', '2026-10-23 09:22:16'),
(45, 9, 'class_teacher_assigned', 'Assigned user 7 as teacher of class 1', '::1', '2026-10-23 09:22:16'),
(46, 9, 'class_member_added', 'Enrolled user 18 in class 1', '::1', '2026-10-23 09:22:16');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `class_id` bigint(20) UNSIGNED NOT NULL,
  `year_section_id` bigint(20) UNSIGNED NOT NULL,
  `teacher_id` bigint(20) UNSIGNED NOT NULL,
  `subject` varchar(150) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`class_id`, `year_section_id`, `teacher_id`, `subject`, `created_at`) VALUES
(1, 1, 7, 'CC106', '2026-10-23 09:22:16');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `course_code` varchar(20) NOT NULL,
  `course_name` varchar(150) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_code`, `course_name`, `created_at`) VALUES
(1, 'BEED', 'Bachelor of Elementary Education', '2026-10-23 09:17:31'),
(2, 'BSED', 'Bachelor of Secondary Education', '2026-10-23 09:17:31'),
(3, 'BTLED', 'Bachelor of Technology and Livelihood Education', '2026-10-23 09:17:31'),
(4, 'BPED', 'Bachelor of Physical Education', '2026-10-23 09:17:31'),
(5, 'BSBA', 'Bachelor of Science in Business Administration', '2026-10-23 09:17:31'),
(6, 'BSN', 'Bachelor of Science in Nursing', '2026-10-23 09:17:31'),
(7, 'BPA', 'Bachelor of Public Administration', '2026-10-23 09:17:31'),
(8, 'ABEL', 'Bachelor of Arts in English Language', '2026-10-23 09:17:31'),
(9, 'BSIT', 'Bachelor of Science in Information Technology', '2026-10-23 09:17:31'),
(10, 'BECED', 'Bachelor of Early Childhood Education', '2026-10-23 09:17:31');

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `class_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `enrolled_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`class_id`, `student_id`, `enrolled_at`) VALUES
(1, 18, '2026-10-23 09:22:16');

-- --------------------------------------------------------

--
-- Table structure for table `linked_accounts`
--

CREATE TABLE `linked_accounts` (
  `linked_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `provider` enum('google','facebook','apple') NOT NULL,
  `provider_user_id` varchar(191) NOT NULL,
  `linked_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `attempt_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `identifier_used` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `was_successful` tinyint(1) NOT NULL,
  `failure_reason` varchar(100) DEFAULT NULL,
  `attempted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`attempt_id`, `user_id`, `identifier_used`, `ip_address`, `was_successful`, `failure_reason`, `attempted_at`) VALUES
(1, NULL, 'schema-check-097fa7c6-c55e-41ef-835a-f8bea5262fac@example.test', '127.0.0.1', 0, 'invalid_credentials', '2026-10-21 09:36:08'),
(2, NULL, 'legacy-check-3fae080a-e2e2-4e39-8b46-5d493e02dd46@example.test', '127.0.0.1', 1, NULL, '2026-10-21 09:38:38'),
(3, NULL, 'superadmin@edu.ph', '::1', 0, 'invalid_credentials', '2026-10-21 09:50:56'),
(4, NULL, 'superadmin@edu.ph', '::1', 0, 'invalid_credentials', '2026-10-21 09:50:57'),
(5, NULL, 'superadmin@edu.ph', '::1', 0, 'invalid_credentials', '2026-10-21 09:51:01'),
(6, NULL, 'superadmin@edu.ph', '::1', 0, 'invalid_credentials', '2026-10-21 09:51:02'),
(7, NULL, 'superadmin@edu.ph', '::1', 0, 'invalid_credentials', '2026-10-21 09:51:02'),
(8, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-21 09:51:26'),
(9, NULL, 'mardyu19@gmail.com', '::1', 1, NULL, '2026-10-21 09:52:01'),
(10, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-21 09:52:48'),
(11, NULL, '123@gmail.com', '::1', 1, NULL, '2026-10-21 17:32:40'),
(12, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-21 17:33:03'),
(13, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-21 17:33:15'),
(14, 18, 'mardyu19@gmail.com', '::1', 1, NULL, '2026-10-21 18:41:05'),
(15, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-21 18:47:19'),
(16, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-22 07:13:01'),
(17, 9, 'superadmin@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-22 07:37:47'),
(18, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-22 07:37:53'),
(19, 7, 'peoro@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-22 07:45:24'),
(20, 7, 'peoro@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-22 07:46:14'),
(21, 7, 'peoro@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-22 07:46:17'),
(22, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-22 07:47:09'),
(23, 7, 'peoro@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-22 07:47:34'),
(24, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-22 07:47:44'),
(25, 7, 'peoro@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-22 07:48:13'),
(26, 9, 'superadmin@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-22 07:48:22'),
(27, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-22 07:48:25'),
(28, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 04:56:25'),
(29, 7, 'peoro@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 04:57:52'),
(30, 7, 'peoro@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 04:57:56'),
(31, 7, 'peoro@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 04:57:57'),
(32, 19, 'juandelacruz@gmail.com', '::1', 0, 'invalid_credentials', '2026-10-23 04:58:56'),
(33, 18, 'mardyu19@gmail.com', '::1', 0, 'invalid_credentials', '2026-10-23 04:59:11'),
(34, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 04:59:23'),
(35, 18, 'mardyu19@gmail.com', '::1', 0, 'invalid_credentials', '2026-10-23 04:59:45'),
(36, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 04:59:51'),
(37, 18, 'mardyu19@gmail.com', '::1', 1, NULL, '2026-10-23 05:00:34'),
(38, 7, 'peoro@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 05:05:07'),
(39, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 05:05:17'),
(40, 7, 'peoro@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 05:05:49'),
(41, 7, 'peoro@edugram.edu', '::1', 1, NULL, '2026-10-23 05:05:53'),
(42, 9, 'superadmin@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 05:06:31'),
(43, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 05:06:34'),
(44, 18, 'mardyu19@gmail.com', '::1', 1, NULL, '2026-10-23 05:07:56'),
(45, 8, 'admin@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 05:08:28'),
(46, 8, 'admin@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 05:08:33'),
(47, 8, 'admin@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 05:08:34'),
(48, 8, 'admin@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 05:08:34'),
(49, 8, 'admin@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 05:08:34'),
(50, 8, 'admin@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 05:08:34'),
(51, 8, 'admin@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 05:08:34'),
(52, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 05:08:42'),
(53, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 05:09:33'),
(54, 18, 'mardyu19@gmail.com', '::1', 1, NULL, '2026-10-23 05:11:01'),
(55, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 05:11:43'),
(56, 18, 'mardyu19@gmail.com', '::1', 1, NULL, '2026-10-23 05:32:03'),
(57, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 05:47:10'),
(58, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 05:54:17'),
(59, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 07:05:23'),
(60, 7, 'peoro@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 07:35:35'),
(61, 7, 'peoro@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 07:35:41'),
(62, 7, 'peoro@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 07:35:46'),
(63, 7, 'peoro@edugram.edu', '::1', 1, NULL, '2026-10-23 07:35:50'),
(64, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 07:36:25'),
(65, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 09:16:25'),
(66, 8, 'admin@edugram.edu', '::1', 0, 'invalid_credentials', '2026-10-23 09:18:37'),
(67, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 09:18:49'),
(68, 8, 'admin@edugram.edu', '::1', 1, NULL, '2026-10-23 09:19:17'),
(69, 9, 'superadmin@edugram.edu', '::1', 1, NULL, '2026-10-23 09:19:30');

-- --------------------------------------------------------

--
-- Table structure for table `majors`
--

CREATE TABLE `majors` (
  `major_id` bigint(20) UNSIGNED NOT NULL,
  `course_id` bigint(20) UNSIGNED NOT NULL,
  `major_name` varchar(150) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `majors`
--

INSERT INTO `majors` (`major_id`, `course_id`, `major_name`, `created_at`) VALUES
(1, 8, 'General', '2026-10-23 09:17:31'),
(2, 10, 'General', '2026-10-23 09:17:31'),
(3, 1, 'General', '2026-10-23 09:17:31'),
(4, 7, 'General', '2026-10-23 09:17:31'),
(5, 4, 'General', '2026-10-23 09:17:31'),
(6, 5, 'General', '2026-10-23 09:17:31'),
(7, 2, 'Social Studies', '2026-10-23 09:17:31'),
(8, 2, 'Science', '2026-10-23 09:17:31'),
(9, 2, 'Mathematics', '2026-10-23 09:17:31'),
(10, 2, 'Filipino', '2026-10-23 09:17:31'),
(11, 2, 'English', '2026-10-23 09:17:31'),
(12, 9, 'Data Analytics', '2026-10-23 09:17:31'),
(13, 9, 'Web and Mobile Technology', '2026-10-23 09:17:31'),
(14, 6, 'General', '2026-10-23 09:17:31'),
(15, 3, 'General', '2026-10-23 09:17:31');

-- --------------------------------------------------------

--
-- Table structure for table `password_history`
--

CREATE TABLE `password_history` (
  `history_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_history`
--

INSERT INTO `password_history` (`history_id`, `user_id`, `password_hash`, `changed_at`) VALUES
(1, 18, '$2b$12$mBN6vWyqKlNcudvEFqQdTOqI9EFZMFbs8jCQ8Q6RZUeoUajiHu98G', '2026-10-23 05:00:24'),
(2, 7, '$2b$12$VlqleF/Ul0tLUCkRkeGhWuuJ0HXfxLeWKVf521.1t91J3h7Hd2LKa', '2026-10-23 05:05:40'),
(3, 8, '$2b$12$BtY7WfWzEmtVXDGPgr9YXOUngUHnepR2cExg//BSfakLN7sH85H6K', '2026-10-23 09:19:08');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `role_id` tinyint(3) UNSIGNED NOT NULL,
  `role_name` varchar(30) NOT NULL,
  `description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`, `description`) VALUES
(1, 'student', 'Joins classes and submits work'),
(2, 'teacher', 'Creates classes and assignments, grades work'),
(3, 'admin', 'Manages users and classes'),
(4, 'super_admin', 'Full system control');

-- --------------------------------------------------------

--
-- Table structure for table `submissions`
--

CREATE TABLE `submissions` (
  `submission_id` bigint(20) UNSIGNED NOT NULL,
  `assignment_id` bigint(20) UNSIGNED NOT NULL,
  `student_id` bigint(20) UNSIGNED NOT NULL,
  `content` text NOT NULL,
  `status` enum('submitted','graded') NOT NULL DEFAULT 'submitted',
  `grade` varchar(20) DEFAULT NULL,
  `feedback` text DEFAULT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `graded_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `two_factor_methods`
--

CREATE TABLE `two_factor_methods` (
  `method_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `method_type` enum('authenticator_app','sms','hardware_key') NOT NULL,
  `secret` varchar(255) DEFAULT NULL,
  `backup_codes` text DEFAULT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` tinyint(3) UNSIGNED NOT NULL,
  `referred_by` bigint(20) UNSIGNED DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `username` varchar(15) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `school_id_number` varchar(30) DEFAULT NULL,
  `year_section_id` bigint(20) UNSIGNED DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `account_status` enum('pending','active','locked','suspended','deleted') NOT NULL DEFAULT 'pending',
  `failed_login_count` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `terms_accepted_at` datetime NOT NULL,
  `referral_code` varchar(12) DEFAULT NULL,
  `password_changed_at` datetime NOT NULL DEFAULT current_timestamp(),
  `theme` enum('light','dark') NOT NULL DEFAULT 'light',
  `language` varchar(10) NOT NULL DEFAULT 'en',
  `privacy_level` enum('public','classmates','private') NOT NULL DEFAULT 'classmates',
  `notify_email` tinyint(1) NOT NULL DEFAULT 1,
  `notify_sms` tinyint(1) NOT NULL DEFAULT 0,
  `notify_push` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `app_user_id` varchar(64) DEFAULT NULL,
  `legacy_salt` varchar(64) DEFAULT NULL
) ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `role_id`, `referred_by`, `email`, `phone`, `username`, `password_hash`, `first_name`, `last_name`, `school_id_number`, `year_section_id`, `avatar`, `bio`, `email_verified`, `account_status`, `failed_login_count`, `locked_until`, `terms_accepted_at`, `referral_code`, `password_changed_at`, `theme`, `language`, `privacy_level`, `notify_email`, `notify_sms`, `notify_push`, `created_at`, `updated_at`, `app_user_id`, `legacy_salt`) VALUES
(7, 2, NULL, 'peoro@edugram.edu', NULL, NULL, '$2b$12$VlqleF/Ul0tLUCkRkeGhWuuJ0HXfxLeWKVf521.1t91J3h7Hd2LKa', 'Sir. Michael', 'Peoro', NULL, NULL, NULL, NULL, 0, 'active', 0, NULL, '2026-10-21 17:38:54', NULL, '2026-10-23 13:05:40', 'light', 'en', 'classmates', 1, 0, 1, '2026-10-21 09:38:54', '2026-10-23 05:05:40', 'u_teacher_demo', 'edugram2026'),
(8, 3, NULL, 'admin@edugram.edu', NULL, NULL, '$2b$12$BtY7WfWzEmtVXDGPgr9YXOUngUHnepR2cExg//BSfakLN7sH85H6K', 'Admin', 'User', NULL, NULL, NULL, NULL, 0, 'active', 0, NULL, '2026-10-21 17:38:54', NULL, '2026-10-23 17:19:08', 'light', 'en', 'classmates', 1, 0, 1, '2026-10-21 09:38:54', '2026-10-23 09:19:08', 'u_admin_demo', 'edugram2026'),
(9, 4, NULL, 'superadmin@edugram.edu', NULL, NULL, '$2b$12$ROUN1jHUuEmNxs/6BBykoeeW2iTk3J5cFUxQK0Mzzu5k48rBp/z5e', 'Super', 'Admin', NULL, NULL, NULL, NULL, 0, 'active', 0, NULL, '2026-10-21 17:38:54', NULL, '2026-10-21 17:51:27', 'light', 'en', 'classmates', 1, 0, 1, '2026-10-21 09:38:54', '2026-10-21 09:51:27', 'u_super_admin_demo', NULL),
(18, 1, NULL, 'mardyu19@gmail.com', NULL, NULL, '$2b$12$mBN6vWyqKlNcudvEFqQdTOqI9EFZMFbs8jCQ8Q6RZUeoUajiHu98G', 'Mardy', 'Ubando', '24-BGU-0361', NULL, NULL, NULL, 0, 'active', 0, NULL, '2026-10-22 02:39:36', NULL, '2026-10-23 13:00:24', 'light', 'en', 'classmates', 1, 0, 1, '2026-10-21 18:39:36', '2026-10-23 05:00:24', NULL, NULL),
(19, 2, NULL, 'juandelacruz@gmail.com', NULL, NULL, '$2b$12$VQGXnbjqXtkB2AXN73D7A.mjDDPKRpc6LZx81XJ6SrP5zePyh7XlW', 'Juan', 'Dela Cruz', 'IT-002-002', NULL, NULL, NULL, 0, 'active', 0, NULL, '2026-10-23 12:58:50', NULL, '2026-10-23 12:58:50', 'light', 'en', 'classmates', 1, 0, 1, '2026-10-23 04:58:50', '2026-10-23 05:09:12', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `session_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `session_token_hash` char(64) NOT NULL,
  `device_name` varchar(150) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `location` varchar(150) DEFAULT NULL,
  `is_trusted` tinyint(1) NOT NULL DEFAULT 0,
  `remember_me` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  `revoked_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `verification_codes`
--

CREATE TABLE `verification_codes` (
  `code_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `code_type` enum('email_verify','phone_verify','password_reset','magic_link') NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `sent_to` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `year_sections`
--

CREATE TABLE `year_sections` (
  `year_section_id` bigint(20) UNSIGNED NOT NULL,
  `major_id` bigint(20) UNSIGNED NOT NULL,
  `year_section_name` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `year_sections`
--

INSERT INTO `year_sections` (`year_section_id`, `major_id`, `year_section_name`, `created_at`) VALUES
(1, 13, '4-1 WMT', '2026-10-23 09:21:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`assignment_id`),
  ADD KEY `idx_assign_due` (`due_date`),
  ADD KEY `fk_assign_class` (`class_id`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_audit_user_time` (`user_id`,`created_at`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`class_id`),
  ADD UNIQUE KEY `uq_class_section_subject_teacher` (`year_section_id`,`subject`,`teacher_id`),
  ADD KEY `fk_class_teacher` (`teacher_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`),
  ADD UNIQUE KEY `uq_courses_code` (`course_code`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`class_id`,`student_id`),
  ADD KEY `fk_enroll_student` (`student_id`);

--
-- Indexes for table `linked_accounts`
--
ALTER TABLE `linked_accounts`
  ADD PRIMARY KEY (`linked_id`),
  ADD UNIQUE KEY `uq_linked_provider` (`provider`,`provider_user_id`),
  ADD KEY `fk_linked_user` (`user_id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`attempt_id`),
  ADD KEY `idx_attempts_ip_time` (`ip_address`,`attempted_at`),
  ADD KEY `fk_attempt_user` (`user_id`);

--
-- Indexes for table `majors`
--
ALTER TABLE `majors`
  ADD PRIMARY KEY (`major_id`),
  ADD UNIQUE KEY `uq_majors_course_name` (`course_id`,`major_name`);

--
-- Indexes for table `password_history`
--
ALTER TABLE `password_history`
  ADD PRIMARY KEY (`history_id`),
  ADD KEY `fk_pwhist_user` (`user_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `uq_roles_name` (`role_name`);

--
-- Indexes for table `submissions`
--
ALTER TABLE `submissions`
  ADD PRIMARY KEY (`submission_id`),
  ADD UNIQUE KEY `uq_submission_once` (`assignment_id`,`student_id`),
  ADD KEY `fk_sub_student` (`student_id`);

--
-- Indexes for table `two_factor_methods`
--
ALTER TABLE `two_factor_methods`
  ADD PRIMARY KEY (`method_id`),
  ADD UNIQUE KEY `uq_2fa_user_type` (`user_id`,`method_type`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD UNIQUE KEY `uq_users_phone` (`phone`),
  ADD UNIQUE KEY `uq_users_username` (`username`),
  ADD UNIQUE KEY `uq_users_school_id` (`school_id_number`),
  ADD UNIQUE KEY `uq_users_referral` (`referral_code`),
  ADD UNIQUE KEY `uq_users_app_user_id` (`app_user_id`),
  ADD KEY `fk_users_role` (`role_id`),
  ADD KEY `fk_users_referred_by` (`referred_by`),
  ADD KEY `fk_users_year_section` (`year_section_id`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD UNIQUE KEY `uq_sessions_token` (`session_token_hash`),
  ADD KEY `fk_session_user` (`user_id`);

--
-- Indexes for table `verification_codes`
--
ALTER TABLE `verification_codes`
  ADD PRIMARY KEY (`code_id`),
  ADD KEY `fk_vcode_user` (`user_id`);

--
-- Indexes for table `year_sections`
--
ALTER TABLE `year_sections`
  ADD PRIMARY KEY (`year_section_id`),
  ADD UNIQUE KEY `uq_year_sections_major_name` (`major_id`,`year_section_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `assignment_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `class_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `linked_accounts`
--
ALTER TABLE `linked_accounts`
  MODIFY `linked_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `attempt_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `majors`
--
ALTER TABLE `majors`
  MODIFY `major_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `password_history`
--
ALTER TABLE `password_history`
  MODIFY `history_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `submissions`
--
ALTER TABLE `submissions`
  MODIFY `submission_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `two_factor_methods`
--
ALTER TABLE `two_factor_methods`
  MODIFY `method_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_sessions`
--
ALTER TABLE `user_sessions`
  MODIFY `session_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `verification_codes`
--
ALTER TABLE `verification_codes`
  MODIFY `code_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `year_sections`
--
ALTER TABLE `year_sections`
  MODIFY `year_section_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assignments`
--
ALTER TABLE `assignments`
  ADD CONSTRAINT `fk_assign_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`) ON DELETE CASCADE;

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `classes`
--
ALTER TABLE `classes`
  ADD CONSTRAINT `fk_class_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `fk_class_year_section` FOREIGN KEY (`year_section_id`) REFERENCES `year_sections` (`year_section_id`);

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `fk_enroll_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_enroll_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `linked_accounts`
--
ALTER TABLE `linked_accounts`
  ADD CONSTRAINT `fk_linked_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD CONSTRAINT `fk_attempt_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `majors`
--
ALTER TABLE `majors`
  ADD CONSTRAINT `fk_majors_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`);

--
-- Constraints for table `password_history`
--
ALTER TABLE `password_history`
  ADD CONSTRAINT `fk_pwhist_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `submissions`
--
ALTER TABLE `submissions`
  ADD CONSTRAINT `fk_sub_assignment` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`assignment_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sub_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `two_factor_methods`
--
ALTER TABLE `two_factor_methods`
  ADD CONSTRAINT `fk_2fa_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_referred_by` FOREIGN KEY (`referred_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`),
  ADD CONSTRAINT `fk_users_year_section` FOREIGN KEY (`year_section_id`) REFERENCES `year_sections` (`year_section_id`) ON DELETE SET NULL;

--
-- Constraints for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD CONSTRAINT `fk_session_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `verification_codes`
--
ALTER TABLE `verification_codes`
  ADD CONSTRAINT `fk_vcode_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `year_sections`
--
ALTER TABLE `year_sections`
  ADD CONSTRAINT `fk_year_sections_major` FOREIGN KEY (`major_id`) REFERENCES `majors` (`major_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
CREATE TABLE permissions (
  permission_id   SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  permission_key  VARCHAR(60) NOT NULL,
  description     VARCHAR(255) DEFAULT NULL,
  UNIQUE KEY uq_permissions_key (permission_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE role_permissions (
  role_id        TINYINT UNSIGNED NOT NULL,
  permission_id  SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (role_id, permission_id),
  CONSTRAINT fk_rp_role FOREIGN KEY (role_id) REFERENCES roles (role_id) ON DELETE CASCADE,
  CONSTRAINT fk_rp_permission FOREIGN KEY (permission_id) REFERENCES permissions (permission_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO permissions (permission_key, description) VALUES
('dashboard.view',     'View the admin dashboard'),
('users.view',         'View and search user accounts'),
('users.create',       'Create user accounts'),
('users.update',       'Edit user accounts and reset passwords'),
('users.deactivate',   'Activate or deactivate user accounts'),
('roles.manage',       'Change user roles and permissions'),
('courses.manage',     'Create, edit, delete courses, majors, year and sections'),
('classes.manage',     'Create, edit, delete classes and enrollments'),
('classes.view',       'View classes the user belongs to'),
('assignments.manage', 'Create, edit, delete assignments'),
('submissions.create', 'Submit work for an assignment'),
('submissions.grade',  'Grade student submissions'),
('audit.view',         'View audit logs');

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.role_id, p.permission_id FROM roles r JOIN permissions p
WHERE r.role_name = 'super_admin';

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.role_id, p.permission_id FROM roles r JOIN permissions p
WHERE r.role_name = 'admin' AND p.permission_key <> 'roles.manage';

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.role_id, p.permission_id FROM roles r JOIN permissions p
WHERE r.role_name = 'teacher'
  AND p.permission_key IN ('classes.view','assignments.manage','submissions.grade');

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.role_id, p.permission_id FROM roles r JOIN permissions p
WHERE r.role_name = 'student'
  AND p.permission_key IN ('classes.view','submissions.create');