const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'perezgilbert684@gmail.com',
        pass: 'ichduyjawqvosjxa' // Replace with your new 16-letter App Password (no spaces)
    }
});

const otp = Math.floor(100000 + Math.random() * 900000);

const mailOptions = {
    from: '"Edugram Admin" <perezgilbert684@gmail.com>',
    to: 'mardyu19@gmail.com',
    subject: 'Edugram Verification Code',
    html: `<h3>Your Edugram OTP is: <b>${otp}</b></h3><p>This code expires in 5 minutes.</p>`
};

transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
        return console.error('Error sending email:', error);
    }
    console.log('OTP sent successfully! Message ID:', info.messageId);
});