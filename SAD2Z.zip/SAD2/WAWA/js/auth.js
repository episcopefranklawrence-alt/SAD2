'use strict';

// -------------------------------------------------------------
// DOM ELEMENTS
// -------------------------------------------------------------
const authScreen = document.getElementById('auth-screen');
const loginView = document.getElementById('login-view');
const registerView = document.getElementById('register-view');
const forgotView = document.getElementById('forgot-view');

// Login Elements
const loginEmailEl = document.getElementById('login-email');
const loginPasswordEl = document.getElementById('login-password');
const loginErrorEl = document.getElementById('login-error');
const loginBtn = document.getElementById('login-btn');

// Registration Elements
const regFirstEl = document.getElementById('reg-first');
const regMiddleEl = document.getElementById('reg-middle');
const regLastEl = document.getElementById('reg-last');
const regEmailEl = document.getElementById('reg-email');
const regIdEl = document.getElementById('reg-id');
const regPhoneEl = document.getElementById('reg-phone');
const regCourseEl = document.getElementById('reg-course');
const regMajorEl = document.getElementById('reg-major');
const regYearEl = document.getElementById('reg-year');
const regSectionEl = document.getElementById('reg-section');
const regPasswordEl = document.getElementById('reg-password');
const regOtpEl = document.getElementById('reg-otp'); // Expected ID: id="reg-otp"
const otpSection = document.getElementById('otp-section'); // Expected ID: id="otp-section"

// Registration Controls
const registerErrorEl = document.getElementById('register-error');
const registerSuccessEl = document.getElementById('register-success');
const registerBtn = document.getElementById('register-btn');
const registerNextBtn = document.getElementById('register-next-btn');
const registerBackBtn = document.getElementById('register-back-btn');
const sendOtpBtn = document.getElementById('send-otp-btn'); // Expected ID: id="send-otp-btn"
const registerStepCount = document.getElementById('register-step-count');
let registrationStep = 0;

// Navigation Links
const goRegisterLink = document.getElementById('go-register-link');
const goLoginLink = document.getElementById('go-login-link');
const forgotPasswordLink = document.getElementById('forgot-password-link');
const goLoginFromForgot = document.getElementById('go-login-from-forgot');

const pwToggles = document.querySelectorAll('.pw-toggle');
let academicOptions = [];
const PASSWORD_HINT = 'At least 8 characters, including uppercase, lowercase, and a number.';

// -------------------------------------------------------------
// HELPER FUNCTIONS
// -------------------------------------------------------------
function validPassword(password) {
  return typeof password === 'string' && password.length >= 8 && /[a-z]/.test(password) && /[A-Z]/.test(password) && /\d/.test(password);
}

function showView(view) {
  [loginView, registerView, forgotView].forEach(v => v?.classList.remove('active'));
  view?.classList.add('active');
  const registrationOpen = view === registerView;
  document.body.classList.toggle('registration-modal-open', registrationOpen);
  if (registrationOpen) {
    setRegistrationStep(0);
    hideError(registerErrorEl);
    hideError(registerSuccessEl);
    window.setTimeout(() => regFirstEl?.focus(), 0);
  }
}

function setRegistrationStep(step) {
  const sections = [...document.querySelectorAll('#register-view [data-register-step]')];
  const indicators = [...document.querySelectorAll('#register-view [data-register-indicator]')];
  if (!sections.length) return;
  registrationStep = Math.max(0, Math.min(step, sections.length - 1));
  sections.forEach((section, index) => section.classList.toggle('active', index === registrationStep));
  indicators.forEach((indicator, index) => {
    indicator.classList.toggle('active', index === registrationStep);
    indicator.classList.toggle('complete', index < registrationStep);
  });
  if (registerStepCount) registerStepCount.textContent = `Step ${registrationStep + 1} of ${sections.length}`;
  registerBackBtn?.classList.toggle('hidden', registrationStep === 0);
  registerNextBtn?.classList.toggle('hidden', registrationStep === sections.length - 1);
  registerBtn?.classList.toggle('hidden', registrationStep !== sections.length - 1);
  hideError(registerErrorEl);
  sections[registrationStep].scrollIntoView({ block: 'nearest' });
}

function validateRegistrationStep() {
  hideError(registerErrorEl);
  if (registrationStep === 0) {
    const missing = [regFirstEl, regLastEl, regEmailEl, regIdEl].find(input => !input?.value.trim());
    if (missing) {
      showError(registerErrorEl, 'Complete your name, email, and student ID to continue.');
      missing?.focus();
      return false;
    }
    if (!regEmailEl.checkValidity()) {
      showError(registerErrorEl, 'Enter a valid email address to continue.');
      regEmailEl.focus();
      return false;
    }
    return true;
  }
  if (registrationStep === 1) {
    const courseId = regCourseEl?.value || '';
    const majorId = regMajorEl?.value || '';
    const year = regYearEl?.value.trim() || '';
    const section = regSectionEl?.value.trim() || '';
    const hasAcademicDetails = [courseId, majorId, year, section].some(Boolean);
    if (hasAcademicDetails && (!courseId || !majorId || !year || !section)) {
      showError(registerErrorEl, 'Choose a course and major, then enter both year and section, or leave all four blank.');
      return false;
    }
    if (year && (!/^[1-6]$/.test(year) || !/^[A-Za-z0-9][A-Za-z0-9 -]{0,15}$/.test(section))) {
      showError(registerErrorEl, 'Enter a year from 1 to 6 and a valid section name.');
      return false;
    }
  }
  if (registrationStep === 2) {
    if (!validPassword(regPasswordEl?.value || '')) {
      showError(registerErrorEl, PASSWORD_HINT);
      regPasswordEl?.focus();
      return false;
    }
  }
  return true;
}

function showError(el, msg) {
  if (!el) return;
  el.textContent = msg;
  el.classList.remove('hidden');
}

function hideError(el) {
  if (!el) return;
  el.classList.add('hidden');
}

function setLoading(btn, loading) {
  if (!btn) return;
  const label = btn.querySelector('.btn-label');
  const spinner = btn.querySelector('.btn-spinner');
  if (loading) {
    label?.classList.add('hidden');
    spinner?.classList.remove('hidden');
    btn.disabled = true;
  } else {
    label?.classList.remove('hidden');
    spinner?.classList.add('hidden');
    btn.disabled = false;
  }
}

// -------------------------------------------------------------
// API HANDLERS
// -------------------------------------------------------------
async function handleLogin(e) {
  e.preventDefault();
  hideError(loginErrorEl);

  const identifier = loginEmailEl?.value.trim();
  const password = loginPasswordEl?.value;

  if (!identifier || !password) {
    showError(loginErrorEl, 'Please fill in all fields');
    return;
  }

  setLoading(loginBtn, true);

  try {
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ identifier, password }),
    });

    const result = await response.json();

    if (!response.ok) {
      showError(loginErrorEl, result.error || 'Login failed');
      setLoading(loginBtn, false);
      return;
    }

    sessionStorage.setItem('edugram_jwt', result.token);
    sessionStorage.setItem('edugram_user_role', result.user.role);

    const roleRedirects = {
      'student': '/student',
      'teacher': '/teacher',
      'admin': '/admin',
      'super_admin': '/superadmin',
    };

    window.location.href = roleRedirects[result.user.role] || '/student';
  } catch (error) {
    console.error('Login request failed:', error);
    showError(loginErrorEl, 'Could not reach the server. Please try again.');
    setLoading(loginBtn, false);
  }
}

async function handleSendOtp() {
  const email = regEmailEl?.value.trim();
  if (!email) {
    showError(registerErrorEl, 'Please enter your email address first.');
    regEmailEl?.focus();
    return;
  }

  try {
    const response = await fetch('/api/send-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    const result = await response.json();

    if (response.ok) {
      alert('Verification code sent! Check your email inbox.');
      if (otpSection) otpSection.style.display = 'block';
    } else {
      showError(registerErrorEl, result.error || 'Failed to send verification code.');
    }
  } catch (err) {
    console.error('Error sending OTP:', err);
    showError(registerErrorEl, 'Network error while requesting verification code.');
  }
}

async function handleRegister(e) {
  e.preventDefault();
  hideError(registerErrorEl);
  hideError(registerSuccessEl);

  const first = regFirstEl?.value.trim();
  const last = regLastEl?.value.trim();
  const email = regEmailEl?.value.trim().toLowerCase();
  const id = regIdEl?.value.trim();
  const phone = regPhoneEl?.value.trim() || '';
  const courseId = regCourseEl?.value || '';
  const majorId = regMajorEl?.value || '';
  const year = regYearEl?.value.trim() || '';
  const section = regSectionEl?.value.trim() || '';
  const password = regPasswordEl?.value || '';
  const otpCode = regOtpEl?.value.trim() || '';

  if (!first || !last || !email || !id || !password || !otpCode) {
    showError(registerErrorEl, 'Please fill in all required fields, including the 6-digit verification code.');
    return;
  }

  if (!validPassword(password)) {
    showError(registerErrorEl, PASSWORD_HINT);
    return;
  }

  setLoading(registerBtn, true);

  try {
    const response = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email,
        password,
        otpCode,
        firstName: first,
        middleName: regMiddleEl?.value.trim() || '',
        lastName: last,
        phone,
        idNumber: id,
        courseId,
        majorId,
        year,
        section,
      }),
    });

    const result = await response.json();

    if (!response.ok) {
      showError(registerErrorEl, result.error || 'Registration failed');
      setLoading(registerBtn, false);
      return;
    }

    if (registerSuccessEl) {
      registerSuccessEl.textContent = 'Account created successfully! Redirecting to login...';
      registerSuccessEl.classList.remove('hidden');
    }

    setTimeout(() => {
      if (loginEmailEl) loginEmailEl.value = email;
      if (loginPasswordEl) loginPasswordEl.value = '';
      showView(loginView);
    }, 2000);
  } catch (error) {
    console.error('Registration request failed:', error);
    showError(registerErrorEl, 'Could not reach the server. Please try again.');
  } finally {
    setLoading(registerBtn, false);
  }
}

async function handleForgot(e) {
  e.preventDefault();
  const forgotErrorEl = document.getElementById('forgot-error');
  const forgotSuccessEl = document.getElementById('forgot-success');
  const forgotEmailEl = document.getElementById('forgot-email');
  const forgotOtpEl = document.getElementById('forgot-otp');
  const forgotPasswordEl = document.getElementById('forgot-password');
  const forgotBtn = document.getElementById('forgot-btn');

  hideError(forgotErrorEl);
  hideError(forgotSuccessEl);

  const email = forgotEmailEl?.value.trim();
  const otpCode = forgotOtpEl?.value.trim();
  const newPassword = forgotPasswordEl?.value;

  if (!email || !otpCode || !newPassword) {
    showError(forgotErrorEl, 'Please enter your email, verification code, and new password.');
    return;
  }

  setLoading(forgotBtn, true);

  try {
    const response = await fetch('/api/forgot-password/reset', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, otpCode, newPassword }),
    });

    const result = await response.json();

    if (response.ok) {
      showError(forgotSuccessEl, result.message || 'Password reset successfully!');
      setTimeout(() => showView(loginView), 2000);
    } else {
      showError(forgotErrorEl, result.error || 'Password reset failed.');
    }
  } catch (err) {
    console.error('Password reset error:', err);
    showError(forgotErrorEl, 'Could not connect to the server.');
  } finally {
    setLoading(forgotBtn, false);
  }
}

// -------------------------------------------------------------
// ACADEMIC OPTIONS CASCADE
// -------------------------------------------------------------
function fillAcademicSelect(select, entries, placeholder, getName = entry => entry.name) {
  if (!select) return;
  select.innerHTML = `<option value="">${placeholder}</option>` + entries.map(entry =>
    `<option value="${String(entry.id).replace(/"/g, '&quot;')}">${String(getName(entry)).replace(/[&<>"']/g, char => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    })[char])}</option>`
  ).join('');
  select.disabled = entries.length === 0;
}

function updateRegistrationAcademicOutput() {
  const output = document.getElementById('reg-academic-output');
  if (!output) return;
  const year = regYearEl?.value.trim() || '';
  const section = regSectionEl?.value.trim().replace(/\s+/g, ' ') || '';
  if (!year && !section) {
    output.textContent = 'Your year and section will appear here.';
    return;
  }
  if (!year || !section) {
    output.textContent = 'Enter both year and section to preview your academic record.';
    return;
  }
  const course = regCourseEl?.value ? regCourseEl.selectedOptions[0]?.textContent : '';
  const major = regMajorEl?.value ? regMajorEl.selectedOptions[0]?.textContent : '';
  output.textContent = course && major
    ? `Academic record: ${course} · ${major} · ${year}-${section}`
    : `Year and section: ${year}-${section}`;
}

function setupRegistrationCascade() {
  regCourseEl?.addEventListener('change', () => {
    const course = academicOptions.find(item => item.id === regCourseEl.value);
    fillAcademicSelect(regMajorEl, course?.majors || [], 'Select major');
    if (regYearEl) regYearEl.value = '';
    if (regSectionEl) regSectionEl.value = '';
    updateRegistrationAcademicOutput();
  });
  regMajorEl?.addEventListener('change', () => {
    if (regYearEl) regYearEl.value = '';
    if (regSectionEl) regSectionEl.value = '';
    updateRegistrationAcademicOutput();
  });
  regYearEl?.addEventListener('input', updateRegistrationAcademicOutput);
  regSectionEl?.addEventListener('input', updateRegistrationAcademicOutput);
}

async function loadRegistrationAcademicOptions() {
  try {
    const response = await fetch('/api/academic/options');
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not load academic options');
    academicOptions = result.courses;
    fillAcademicSelect(regCourseEl, academicOptions.map(course => ({
      id: course.id, name: `${course.code} - ${course.name}`,
    })), 'Select course');
    fillAcademicSelect(regMajorEl, [], 'Select major');
    setupRegistrationCascade();
    updateRegistrationAcademicOutput();
  } catch (error) {
    console.error('Registration academic options load failed:', error);
    const errorEl = document.getElementById('reg-class-error');
    if (errorEl) {
      errorEl.textContent = error.message || 'Could not load academic options.';
      errorEl.classList.remove('hidden');
    }
  }
}

// -------------------------------------------------------------
// INITIALIZATION & EVENT LISTENERS
// -------------------------------------------------------------
pwToggles.forEach(toggle => {
  toggle.addEventListener('click', function() {
    const targetId = this.getAttribute('data-target');
    const input = document.getElementById(targetId);
    if (!input) return;
    const eyeShow = this.querySelector('.eye-show');
    const eyeHide = this.querySelector('.eye-hide');

    if (input.type === 'password') {
      input.type = 'text';
      if (eyeShow) eyeShow.style.display = 'none';
      if (eyeHide) eyeHide.style.display = 'block';
    } else {
      input.type = 'password';
      if (eyeShow) eyeShow.style.display = 'block';
      if (eyeHide) eyeHide.style.display = 'none';
    }
  });
});

loginBtn?.addEventListener('click', handleLogin);
registerBtn?.addEventListener('click', handleRegister);
sendOtpBtn?.addEventListener('click', handleSendOtp);
registerNextBtn?.addEventListener('click', () => {
  if (validateRegistrationStep()) setRegistrationStep(registrationStep + 1);
});
registerBackBtn?.addEventListener('click', () => setRegistrationStep(registrationStep - 1));
goRegisterLink?.addEventListener('click', (e) => { e.preventDefault(); showView(registerView); });
registerView?.addEventListener('click', event => {
  if (event.target === registerView) showView(loginView);
});
goLoginLink?.addEventListener('click', (e) => { e.preventDefault(); showView(loginView); });
forgotPasswordLink?.addEventListener('click', (e) => { e.preventDefault(); showView(forgotView); });
goLoginFromForgot?.addEventListener('click', (e) => { e.preventDefault(); showView(loginView); });
document.getElementById('forgot-btn')?.addEventListener('click', handleForgot);

document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && registerView?.classList.contains('active')) showView(loginView);
});

// Load academic options on page ready
loadRegistrationAcademicOptions();

async function handleSendForgotOtp() {
  const email = document.getElementById('forgot-email')?.value.trim();
  const forgotErrorEl = document.getElementById('forgot-error');
  const forgotSuccessEl = document.getElementById('forgot-success');

  hideError(forgotErrorEl);
  hideError(forgotSuccessEl);

  if (!email) {
    showError(forgotErrorEl, 'Please enter your email address first.');
    document.getElementById('forgot-email')?.focus();
    return;
  }

  // Optional: Disable button briefly to prevent spam clicks
  const sendBtn = document.getElementById('send-forgot-otp-btn');
  if (sendBtn) sendBtn.disabled = true;

  try {
    const response = await fetch('/api/send-otp', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      // Flag this request as a password reset
      body: JSON.stringify({ email, isPasswordReset: true }),
    });
    const result = await response.json();

    if (response.ok) {
      alert('Verification code sent! Check your email inbox.');
    } else {
      showError(forgotErrorEl, result.error || 'Failed to send verification code.');
    }
  } catch (err) {
    console.error('Error sending reset OTP:', err);
    showError(forgotErrorEl, 'Network error while requesting verification code.');
  } finally {
    if (sendBtn) sendBtn.disabled = false;
  }
}
document.getElementById('send-forgot-otp-btn')?.addEventListener('click', handleSendForgotOtp);