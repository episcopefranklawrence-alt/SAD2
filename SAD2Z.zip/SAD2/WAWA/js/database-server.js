const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');

const DB_DIR = path.join(__dirname, '..', 'database');
const DB_FILE = path.join(DB_DIR, 'edugram-db.json');

function pseudoHash(password, salt) {
  const str = salt + ':' + password;
  let hash = 0;
  for (let i = 0; i < str.length; i += 1) {
    const chr = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + chr;
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0');
  return Buffer.from(salt + '$' + hex, 'utf8').toString('base64').replace(/=/g, '');
}

function verifyPseudoHash(password, storedHash, salt) {
  try {
    return pseudoHash(password, salt) === storedHash;
  } catch {
    return false;
  }
}

async function hashPassword(password) {
  return bcrypt.hash(password, 12);
}

async function verifyPassword(password, user) {
  const storedHash = typeof user === 'string' ? user : user.passwordHash;
  const salt = typeof user === 'string' ? undefined : user.salt;

  if (storedHash && storedHash.startsWith('$2')) {
    return bcrypt.compare(password, storedHash);
  }
  if (typeof storedHash === 'string' && storedHash.startsWith('legacy$')) {
    const [, encodedSalt, legacyHash] = storedHash.split('$');
    if (!encodedSalt || !legacyHash) return false;
    return verifyPseudoHash(password, legacyHash, Buffer.from(encodedSalt, 'base64url').toString('utf8'));
  }
  if (salt) {
    return verifyPseudoHash(password, storedHash, salt);
  }
  return false;
}

function defaultData() {
  return {
    users: [],
    assignments: [],
    submissions: [],
    drafts: {},
  };
}

function ensureDatabase() {
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) writeDatabase(defaultData());
}

function normalizeData(data) {
  return {
    users: Array.isArray(data.users) ? data.users : [],
    assignments: Array.isArray(data.assignments) ? data.assignments : [],
    submissions: Array.isArray(data.submissions) ? data.submissions : [],
    drafts: data.drafts && typeof data.drafts === 'object' ? data.drafts : {},
  };
}

function readDatabase() {
  ensureDatabase();
  const raw = fs.readFileSync(DB_FILE, 'utf8');
  return normalizeData(JSON.parse(raw));
}

function writeDatabase(data) {
  if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
  fs.writeFileSync(DB_FILE, JSON.stringify(normalizeData(data), null, 2));
  return normalizeData(data);
}

function publicUser(user) {
  if (!user) return null;
  const { passwordHash, password_hash, password, salt, _dbUserId, ...safeUser } = user;
  return safeUser;
}

module.exports = {
  DB_FILE,
  hashPassword,
  verifyPassword,
  readDatabase,
  writeDatabase,
  publicUser,
};