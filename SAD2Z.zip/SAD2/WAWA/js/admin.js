'use strict';

const jwt = sessionStorage.getItem('edugram_jwt');
const userRole = sessionStorage.getItem('edugram_user_role');
const decoded = jwt ? decodeJwtPayload(jwt) : null;

if (!decoded || (userRole !== 'admin' && userRole !== 'super_admin')) window.location.href = 'index.php';

let currentUser = USERS.find(user => user.id === (decoded?.userId || decoded?.sub));
let peopleFilter = 'all';
let peoplePage = 1;
const PEOPLE_PAGE_SIZE = 10;
let editingUserId = null;
let classes = [];
let classesPage = 1;
const CLASSES_PAGE_SIZE = 8;
let editingClassId = null;
let academicCourses = [];
let editingAcademic = null;
const academicPages = { courses: 1, majors: 1, years: 1 };
const ACADEMIC_PAGE_SIZE = 8;

if (!currentUser) {
  sessionStorage.clear();
  window.location.href = 'index.php';
}

const $ = id => document.getElementById(id);
const html = value => String(value ?? '').replace(/[&<>"']/g, char => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[char]));

function initAdminDashboard() {
  $('auth-screen')?.style && ($('auth-screen').style.display = 'none');
  $('admin-screen')?.style && ($('admin-screen').style.display = 'flex');
  if (userRole !== 'super_admin') {
    document.querySelector('.nav-item[data-panel="a-academic"]')?.remove();
    $('a-academic')?.remove();
  }
  updateChrome();
  setupNavigation();
  setupPeople();
  renderPeople();
  setupAcademic();
  refreshAcademic();
  setupClasses();
  setupPasswordStrength('np-pass', 'np-password-strength');
  setupPasswordStrength('vp-pass', 'vp-password-strength');
  refreshClasses();
  $('admin-menu-toggle')?.addEventListener('click', () => $('admin-sidebar')?.classList.toggle('active'));
}

function updateChrome() {
  const initials = ((currentUser.firstName?.[0] || 'A') + (currentUser.lastName?.[0] || '')).toUpperCase();
  if ($('admin-avatar')) $('admin-avatar').textContent = initials;
  if ($('admin-name')) $('admin-name').textContent = [currentUser.firstName, currentUser.middleName, currentUser.lastName].filter(Boolean).join(' ');
  if ($('admin-welcome-name')) $('admin-welcome-name').textContent = currentUser.firstName;
}

function setupNavigation() {
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', event => {
      event.preventDefault();
      showPanel(item.dataset.panel);
    });
  });
  document.querySelectorAll('[data-superadmin-panel]').forEach(button => {
    button.addEventListener('click', () => showPanel(button.dataset.superadminPanel));
  });
}

function showPanel(panelId) {
  if (panelId === 'a-academic' && userRole !== 'super_admin') panelId = 'a-overview';
  document.querySelectorAll('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.panel === panelId));
  document.querySelectorAll('.panel').forEach(panel => panel.classList.toggle('active', panel.id === panelId));
  $('admin-sidebar')?.classList.remove('active');
  if (panelId === 'a-people') renderPeople();
  if (panelId === 'a-sections') refreshClasses();
  if (panelId === 'a-academic') refreshAcademic();
}

function setupPeople() {
  $('add-person-btn')?.addEventListener('click', () => openAddPerson('student'));
  $('add-teacher-btn')?.addEventListener('click', () => openAddPerson('teacher'));
  $('people-search')?.addEventListener('input', () => { peoplePage = 1; renderPeople(); });
  document.querySelectorAll('[data-prole]').forEach(button => button.addEventListener('click', () => {
    peopleFilter = button.dataset.prole;
    peoplePage = 1;
    document.querySelectorAll('[data-prole]').forEach(btn => btn.classList.toggle('active', btn === button));
    renderPeople();
  }));
  document.querySelectorAll('[data-statfilter]').forEach(stat => stat.addEventListener('click', () => {
    peopleFilter = stat.dataset.statfilter;
    peoplePage = 1;
    renderPeople();
  }));
  ['add-person-close', 'add-person-backdrop', 'np-cancel'].forEach(id => $(id)?.addEventListener('click', closeAddPerson));
  $('np-save')?.addEventListener('click', saveNewPerson);
  $('np-role-select')?.addEventListener('change', updateAddPersonLabels);
  ['view-person-close', 'view-person-backdrop', 'vp-cancel'].forEach(id => $(id)?.addEventListener('click', closeViewPerson));
  $('vp-save')?.addEventListener('click', saveViewedPerson);
  $('vp-password-save')?.addEventListener('click', updateViewedPersonPassword);
  $('vp-status-save')?.addEventListener('click', updateViewedPersonStatus);
  $('vp-delete')?.addEventListener('click', deleteViewedPerson);
  ['subs-detail-close', 'subs-detail-backdrop', 'subs-detail-cancel'].forEach(id => $(id)?.addEventListener('click', () => $('submissions-detail-modal')?.classList.add('hidden')));
}

function renderPeople() {
  updatePeopleStats();
  const grid = $('people-grid');
  if (!grid) return;
  const query = ($('people-search')?.value || '').toLowerCase();
  const submitterIds = new Set(SUBMISSIONS.map(s => s.studentId));
  let users = USERS.filter(user => user.id !== currentUser.id);

  if (peopleFilter === 'student' || peopleFilter === 'teacher') users = users.filter(user => user.role === peopleFilter);
  if (peopleFilter === 'submissions') users = users.filter(user => submitterIds.has(user.id));
  if (query) {
    users = users.filter(user => [user.firstName, user.middleName, user.lastName, user.email, user.studentId, user.employeeId, user.adminId]
      .some(value => String(value || '').toLowerCase().includes(query)));
  }

  const pageCount = Math.max(1, Math.ceil(users.length / PEOPLE_PAGE_SIZE));
  peoplePage = Math.min(peoplePage, pageCount);
  const pageUsers = users.slice((peoplePage - 1) * PEOPLE_PAGE_SIZE, peoplePage * PEOPLE_PAGE_SIZE);
  grid.innerHTML = pageUsers.length ? pageUsers.map(user => {
    const subCount = SUBMISSIONS.filter(s => s.studentId === user.id).length;
    return `<tr><td>${html([user.firstName, user.middleName, user.lastName].filter(Boolean).join(' '))}</td><td>${html(user.email)}</td><td><span class="status-badge">${html(user.role)}</span></td><td>${html(user.studentId || user.employeeId || user.adminId || '—')}</td><td>${subCount}</td><td><button class="btn-primary small view-person" data-id="${html(user.id)}">View / Edit</button></td></tr>`;
  }).join('') : '<tr><td colspan="6" class="empty-hint">No people found.</td></tr>';

  grid.querySelectorAll('.view-person').forEach(el => el.addEventListener('click', () => openViewPerson(el.dataset.id)));
  const pagination = $('people-pagination');
  if (pagination) {
    const start = users.length ? (peoplePage - 1) * PEOPLE_PAGE_SIZE + 1 : 0;
    const end = Math.min(peoplePage * PEOPLE_PAGE_SIZE, users.length);
    pagination.innerHTML = `<span>Showing ${start}–${end} of ${users.length}</span><div class="pagination-buttons"><button class="btn-secondary small" data-page="${peoplePage - 1}" ${peoplePage <= 1 ? 'disabled' : ''}>Previous</button><span>Page ${peoplePage} of ${pageCount}</span><button class="btn-secondary small" data-page="${peoplePage + 1}" ${peoplePage >= pageCount ? 'disabled' : ''}>Next</button></div>`;
    pagination.querySelectorAll('[data-page]').forEach(button => button.addEventListener('click', () => {
      peoplePage = Number(button.dataset.page);
      renderPeople();
    }));
  }
}

function updatePeopleStats() {
  if ($('pstat-total')) $('pstat-total').textContent = USERS.length;
  if ($('pstat-students')) $('pstat-students').textContent = USERS.filter(u => u.role === 'student').length;
  if ($('pstat-teachers')) $('pstat-teachers').textContent = USERS.filter(u => u.role === 'teacher').length;
  const submitterIds = new Set(SUBMISSIONS.map(s => s.studentId));
  if ($('pstat-active')) $('pstat-active').textContent = USERS.filter(u => submitterIds.has(u.id)).length;
}

function openAddPerson(role) {
  editingUserId = null;
  ['np-first', 'np-middle', 'np-last', 'np-email', 'np-id', 'np-pass'].forEach(id => {
    if ($(id)) $(id).value = '';
  });
  if ($('np-role-select')) $('np-role-select').value = role;
  updateAddPersonLabels();
  $('np-error')?.classList.add('hidden');
  $('np-success')?.classList.add('hidden');
  $('add-person-modal')?.classList.remove('hidden');
}

function updateAddPersonLabels() {
  const role = $('np-role-select')?.value || 'student';
  const titles = {
    teacher: 'Add New Teacher',
    admin: 'Add New Admin',
    super_admin: 'Add New Super Admin',
    student: 'Add New Student',
  };
  if ($('add-person-modal-title')) $('add-person-modal-title').textContent = titles[role] || 'Add New Student';
  if ($('np-id-label')) {
    $('np-id-label').textContent = role === 'teacher' ? 'Employee ID *'
      : (role === 'admin' || role === 'super_admin') ? 'Admin ID *'
      : 'Student ID *';
  }
}

function closeAddPerson() {
  $('add-person-modal')?.classList.add('hidden');
}

async function saveNewPerson() {
  const role = $('np-role-select')?.value || 'student';
  const first = $('np-first')?.value.trim();
  const middle = $('np-middle')?.value.trim() || '';
  const last = $('np-last')?.value.trim();
  const email = $('np-email')?.value.trim();
  const id = $('np-id')?.value.trim();
  const pass = $('np-pass')?.value || '';
  if (!first || !last || !email || !id || !pass) return showMessage('np-error', 'Please complete all required fields.');
  if (pass.length < 8 || !/[a-z]/.test(pass) || !/[A-Z]/.test(pass) || !/\d/.test(pass)) {
    return showMessage('np-error', 'At least 8 characters, including uppercase, lowercase, and a number. A symbol is optional and may improve strength.');
  }
  if (USERS.some(user => user.email?.toLowerCase() === email.toLowerCase())) return showMessage('np-error', 'Email already exists.');

  const token = sessionStorage.getItem('edugram_jwt');
  if (role === 'super_admin' && sessionStorage.getItem('edugram_user_role') !== 'super_admin') {
    return showMessage('np-error', 'Only a super admin can create another super admin.');
  }
  const body = {
    email,
    password: pass,
    firstName: first,
    middleName: middle,
    lastName: last,
    studentId: id,
  };

  try {
    const response = await fetch('/api/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: 'Bearer ' + token } : {}),
      },
      body: JSON.stringify(body),
    });
    const result = await response.json();
    if (!response.ok) return showMessage('np-error', result.error || 'Failed to add person.');

    let newUser = result.user;
    if (role !== 'student') {
      const roleResponse = await fetch(`/api/users/${encodeURIComponent(newUser.id)}/role`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: 'Bearer ' + token } : {}),
        },
        body: JSON.stringify({ role }),
      });
      const roleResult = await roleResponse.json();
      if (!roleResponse.ok) {
        const deleteResponse = await fetch(`/api/users/${encodeURIComponent(newUser.id)}`, {
          method: 'DELETE',
          headers: token ? { Authorization: 'Bearer ' + token } : {},
        });
        if (!deleteResponse.ok) console.error('Failed to remove unpromoted account', await deleteResponse.text());
        return showMessage('np-error', roleResult.error || 'Failed to assign the requested role.');
      }
      newUser = roleResult.user;
    }

    USERS.push(newUser);
    showMessage('np-success', 'Person added.');
    closeAddPerson();
    renderPeople();
  } catch (error) {
    console.error('Add person request failed', error);
    showMessage('np-error', 'Could not reach the server. Please try again.');
  }
}

function openViewPerson(id) {
  const user = USERS.find(u => u.id === id);
  if (!user) return;
  editingUserId = id;
  const initials = ((user.firstName?.[0] || 'U') + (user.lastName?.[0] || '')).toUpperCase();
  $('vp-avatar').textContent = initials;
  $('vp-name').textContent = [user.firstName, user.middleName, user.lastName].filter(Boolean).join(' ');
  $('vp-role-badge').textContent = user.role;
  $('vp-account-status').value = user.accountStatus || 'active';
  $('vp-first').value = user.firstName || '';
  $('vp-middle').value = user.middleName || '';
  $('vp-last').value = user.lastName || '';
  $('vp-email').value = user.email || '';
  $('vp-sid').value = user.studentId || user.employeeId || user.adminId || '';
  $('vp-year-section').value = user.yearSectionId || '';
  $('vp-role-manager')?.classList.toggle('hidden', user.role === 'super_admin');
  if (user.role !== 'super_admin') $('vp-role').value = user.role;
  $('vp-pass').value = '';
  $('vp-password-error')?.classList.add('hidden');
  $('vp-password-success')?.classList.add('hidden');
  $('vp-password-manager')?.classList.toggle('hidden',
    !(['student', 'teacher'].includes(user.role) || currentUser.role === 'super_admin'));
  $('vp-status-manager')?.classList.toggle('hidden',
    currentUser.id === user.id || (currentUser.role === 'admin' && !['student', 'teacher'].includes(user.role))
    || user.role === 'super_admin');
  const subs = SUBMISSIONS.filter(s => s.studentId === user.id);
  $('vp-activity').innerHTML = `<strong>${subs.length}</strong> submission${subs.length === 1 ? '' : 's'} recorded.`;
  $('view-person-modal')?.classList.remove('hidden');
}

function closeViewPerson() {
  editingUserId = null;
  $('view-person-modal')?.classList.add('hidden');
}

async function saveViewedPerson() {
  const user = USERS.find(u => u.id === editingUserId);
  if (!user) return;
  const first = $('vp-first')?.value.trim();
  const middle = $('vp-middle')?.value.trim() || '';
  const last = $('vp-last')?.value.trim();
  const email = $('vp-email')?.value.trim();
  const selectedRole = $('vp-role')?.value;
  if (!first || !last || !email) return showMessage('vp-error', 'Name and email are required.');
  if (USERS.some(u => u.email.toLowerCase() === email.toLowerCase() && u.id !== user.id)) return showMessage('vp-error', 'Email already exists.');
  if (!['student', 'teacher', 'admin'].includes(selectedRole)) {
    return showMessage('vp-error', 'Select a valid role.');
  }
  const token = sessionStorage.getItem('edugram_jwt');
  try {
    const response = await fetch(`/api/users/${encodeURIComponent(user.id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token || ''}` },
      body: JSON.stringify({
        firstName: first,
        middleName: middle,
        lastName: last,
        email,
        phone: user.phone || '',
        studentId: $('vp-sid')?.value.trim() || '',
        yearSectionId: $('vp-year-section')?.value || null,
      }),
    });
    const result = await response.json();
    if (!response.ok) return showMessage('vp-error', result.error || 'Could not update profile.');
    Object.assign(user, result.user);
    if (selectedRole !== user.role) {
      const roleResponse = await fetch(`/api/users/${encodeURIComponent(user.id)}/role`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token || ''}` },
        body: JSON.stringify({ role: selectedRole }),
      });
      const roleResult = await roleResponse.json();
      if (!roleResponse.ok) {
        renderPeople();
        return showMessage('vp-error', roleResult.error || 'Profile saved, but role update failed.');
      }
      Object.assign(user, roleResult.user);
    }
  } catch (error) {
    console.error('Profile update request failed', error);
    return showMessage('vp-error', 'Could not reach the server. Please try again.');
  }
  closeViewPerson();
  renderPeople();
}

async function updateViewedPersonPassword() {
  const user = USERS.find(person => person.id === editingUserId);
  if (!user || (currentUser.role === 'admin' && !['student', 'teacher'].includes(user.role))) return;

  const password = $('vp-pass')?.value || '';
  if (password.length < 8 || !/[a-z]/.test(password) || !/[A-Z]/.test(password) || !/\d/.test(password)) {
    $('vp-password-success')?.classList.add('hidden');
    showMessage('vp-password-error', 'At least 8 characters, including uppercase, lowercase, and a number. A symbol is optional and may improve strength.');
    return;
  }

  try {
    const response = await fetch(`/api/users/${encodeURIComponent(user.id)}/password`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${sessionStorage.getItem('edugram_jwt') || ''}`,
      },
      body: JSON.stringify({ password }),
    });
    const result = await response.json();
    if (!response.ok) {
      $('vp-password-success')?.classList.add('hidden');
      return showMessage('vp-password-error', result.error || 'Could not update password.');
    }

    $('vp-pass').value = '';
    $('vp-password-error')?.classList.add('hidden');
    showMessage('vp-password-success', `Password updated for ${user.firstName} ${user.lastName}.`);
  } catch (error) {
    console.error('Password update request failed', error);
    $('vp-password-success')?.classList.add('hidden');
    showMessage('vp-password-error', 'Could not reach the server. Please try again.');
  }
}

async function updateViewedPersonStatus() {
  const user = USERS.find(person => person.id === editingUserId);
  if (!user) return;
  try {
    const response = await fetch(`/api/users/${encodeURIComponent(user.id)}/status`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${sessionStorage.getItem('edugram_jwt') || ''}`,
      },
      body: JSON.stringify({ status: $('vp-account-status').value }),
    });
    const result = await response.json();
    if (!response.ok) {
      showMessage('vp-status-error', result.error || 'Could not update account status.');
      return;
    }
    Object.assign(user, result.user);
    $('vp-status-error')?.classList.add('hidden');
    renderPeople();
  } catch (error) {
    console.error('Account status update failed', error);
    showMessage('vp-status-error', 'Could not reach the server. Account status was not saved.');
  }
}

async function deleteViewedPerson() {
  if (!editingUserId || !confirm('Remove this user?')) return;
  const token = sessionStorage.getItem('edugram_jwt');

  try {
    const response = await fetch(`/api/users/${editingUserId}`, {
      method: 'DELETE',
      headers: token ? { Authorization: 'Bearer ' + token } : {},
    });
    const result = await response.json();
    if (!response.ok) {
      alert(result.error || 'Failed to delete user.');
      return;
    }

    USERS = result.data.users;
    ASSIGNMENTS = result.data.assignments;
    SUBMISSIONS = result.data.submissions;
    DRAFTS = result.data.drafts;

    closeViewPerson();
    renderPeople();
  } catch (error) {
    console.error('Delete user request failed', error);
    alert('Could not reach the server. Please try again.');
  }
}

function setupClasses() {
  $('class-save')?.addEventListener('click', saveClass);
  $('class-cancel')?.addEventListener('click', resetClassForm);
  $('class-member-select')?.addEventListener('change', () => loadClassMembers($('class-member-select').value));
  $('class-add-members-btn')?.addEventListener('click', addClassMembers);
  $('classes-pagination')?.addEventListener('click', event => {
    const button = event.target.closest('button[data-page]');
    if (!button || button.disabled) return;
    classesPage = Number(button.dataset.page);
    renderClassesList();
  });
  $('class-course')?.addEventListener('change', () => populateAcademicSelect('class-major', selectedCourse()));
  $('class-major')?.addEventListener('change', () => populateYearSections('class-year-section', selectedMajor()));
  $('classes-table-body')?.addEventListener('click', async event => {
    const button = event.target.closest('button[data-action]');
    if (!button) return;
    const item = classes.find(classInfo => classInfo.id === button.dataset.id);
    if (!item) return;
    clearClassStatus();
    if (button.dataset.action === 'edit') {
      editingClassId = item.id;
      selectAcademicPath('class-course', 'class-major', 'class-year-section', item.yearSectionId);
      $('class-subject').value = item.subject;
      $('class-teacher').value = item.teacherId;
      $('class-save').textContent = 'Save changes';
      $('class-cancel')?.classList.remove('hidden');
      return;
    }
    if (button.dataset.action === 'members') {
      $('class-member-select').value = item.id;
      await loadClassMembers(item.id);
      return;
    }
    if (button.dataset.action === 'delete' && confirm('Delete "' + classLabel(item) + '"? Its enrollments will be removed.')) {
      const result = await performClassAction('/api/classes/' + encodeURIComponent(item.id), 'DELETE');
      if (result) showClassStatus('Class deleted.');
    }
  });
  $('class-members-list')?.addEventListener('click', async event => {
    const button = event.target.closest('button[data-user-id]');
    if (!button) return;
    const classId = $('class-member-select').value;
    if (classId) {
      const result = await performClassAction('/api/classes/' + encodeURIComponent(classId) + '/members/' + encodeURIComponent(button.dataset.userId), 'DELETE');
      if (result) showClassStatus('Student removed from this class.');
    }
  });
}

function selectedCourse() {
  return academicCourses.find(course => course.id === $('class-course')?.value);
}

function selectedMajor() {
  return academicCourses.flatMap(course => course.majors).find(major => major.id === $('class-major')?.value);
}

function classLabel(item) {
  return `${item.courseCode} - ${item.majorName} - ${item.yearSectionName} - ${item.subject}`;
}

function selectOptions(items, placeholder, selectedId = '') {
  return `<option value="">${placeholder}</option>${items.map(item =>
    `<option value="${html(item.id)}" ${item.id === selectedId ? 'selected' : ''}>${html(item.label)}</option>`
  ).join('')}`;
}

function populateAcademicSelect(selectId, course = null, selectedId = '') {
  const select = $(selectId);
  if (!select) return;
  const majors = course?.majors || [];
  select.innerHTML = selectOptions(
    majors.map(major => ({ id: major.id, label: major.name })),
    'Select major',
    selectedId
  );
  select.disabled = !majors.length;
}

function populateYearSections(selectId, major = null, selectedId = '') {
  const select = $(selectId);
  if (!select) return;
  const yearSections = major?.yearSections || [];
  select.innerHTML = selectOptions(
    yearSections.map(yearSection => ({ id: yearSection.id, label: yearSection.name })),
    'Select year and section',
    selectedId
  );
  select.disabled = !yearSections.length;
}

function selectAcademicPath(courseSelectId, majorSelectId, yearSelectId, yearSectionId) {
  const found = academicCourses.flatMap(course =>
    course.majors.flatMap(major => major.yearSections.map(yearSection => ({
      course, major, yearSection,
    })))
  ).find(path => path.yearSection.id === yearSectionId);
  if (!found) return;
  $(courseSelectId).value = found.course.id;
  const majorSelect = $(majorSelectId);
  majorSelect.innerHTML = selectOptions(
    found.course.majors.map(major => ({ id: major.id, label: major.name })),
    'Select major',
    found.major.id
  );
  majorSelect.disabled = false;
  const yearSelect = $(yearSelectId);
  yearSelect.innerHTML = selectOptions(
    found.major.yearSections.map(yearSection => ({ id: yearSection.id, label: yearSection.name })),
    'Select year and section',
    found.yearSection.id
  );
  yearSelect.disabled = false;
}

async function refreshClasses() {
  try {
    const response = await fetch('/api/classes', { headers: { Authorization: 'Bearer ' + (sessionStorage.getItem('edugram_jwt') || '') } });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not load classes');
    classes = result.classes;
    renderClassesList();
    $('classes-error')?.classList.add('hidden');
    const memberSelect = $('class-member-select');
    const selectedId = memberSelect.value;
    memberSelect.innerHTML = '<option value="">Select a class</option>' + classes.map(item =>
      '<option value="' + html(item.id) + '">' + html(classLabel(item)) + '</option>'
    ).join('');
    if (classes.some(item => item.id === selectedId)) memberSelect.value = selectedId;
    $('class-teacher').innerHTML = '<option value="">Select teacher</option>' + USERS
      .filter(user => user.role === 'teacher')
      .map(user => '<option value="' + html(user.id) + '">' + html([user.firstName, user.middleName, user.lastName].filter(Boolean).join(' ')) + '</option>')
      .join('');
    if (memberSelect.value) await loadClassMembers(memberSelect.value);
    else $('class-members-list').innerHTML = '<p class="empty-hint">Select a class to view its members.</p>';
  } catch (error) {
    console.error('Classes refresh failed', error);
    showMessage('classes-error', error.message || 'Could not refresh classes.');
  }
}

function renderClassesList() {
  const tbody = $('classes-table-body');
  if (!tbody) return;
  const pageCount = Math.max(1, Math.ceil(classes.length / CLASSES_PAGE_SIZE));
  classesPage = Math.min(Math.max(1, classesPage), pageCount);
  const startIndex = (classesPage - 1) * CLASSES_PAGE_SIZE;
  const visibleClasses = classes.slice(startIndex, startIndex + CLASSES_PAGE_SIZE);
  tbody.innerHTML = visibleClasses.length ? visibleClasses.map(item =>
    '<tr><td><span class="class-course-name">' + html(item.courseName) + '</span><span class="class-course-code">' + html(item.courseCode) + '</span></td><td>' + html(item.yearSectionName) + '</td><td>' + html(item.majorName) + '</td><td>' + html(item.subject) + '</td><td class="class-teacher-name">' + html(item.teacherName || '-') + '</td><td>' + html(item.memberCount) + '</td><td>' +
    '<div class="class-row-actions">' +
    '<button type="button" class="btn-secondary small" data-action="members" data-id="' + html(item.id) + '">Members</button>' +
    '<button type="button" class="btn-secondary small" data-action="edit" data-id="' + html(item.id) + '">Edit</button>' +
    '<button type="button" class="btn-secondary small" data-action="delete" data-id="' + html(item.id) + '">Delete</button></div></td></tr>'
  ).join('') : '<tr><td colspan="7">No classes found.</td></tr>';

  const pagination = $('classes-pagination');
  if (!pagination) return;
  const start = classes.length ? startIndex + 1 : 0;
  const end = Math.min(startIndex + CLASSES_PAGE_SIZE, classes.length);
  pagination.innerHTML = `<span>Showing ${start}–${end} of ${classes.length}</span><div class="pagination-buttons"><button type="button" class="btn-secondary small" data-page="${classesPage - 1}" ${classesPage <= 1 ? 'disabled' : ''}>Previous</button><span>Page ${classesPage} of ${pageCount}</span><button type="button" class="btn-secondary small" data-page="${classesPage + 1}" ${classesPage >= pageCount ? 'disabled' : ''}>Next</button></div>`;
}

async function loadClassMembers(classId) {
  const membersList = $('class-members-list');
  $('class-members-report')?.classList.add('hidden');
  if (!classId) {
    membersList.innerHTML = '<p class="empty-hint">Select a class to view its members.</p>';
    return;
  }
  try {
    const response = await fetch('/api/classes/' + encodeURIComponent(classId) + '/members', { headers: { Authorization: 'Bearer ' + (sessionStorage.getItem('edugram_jwt') || '') } });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not load class members');
    membersList.innerHTML = result.members.length ? '<div class="table-wrap"><table><thead><tr><th>Name</th><th>Role</th><th>ID number</th><th>Email</th><th>Year and Section</th><th></th></tr></thead><tbody>' +
      result.members.map(member => '<tr><td>' + html([member.firstName, member.middleName, member.lastName].filter(Boolean).join(' ')) + '</td><td>' + html(member.role) + '</td><td>' + html(member.studentId || '-') + '</td><td>' + html(member.email || '-') + '</td><td>' + html([member.courseCode, member.majorName, member.yearSectionName].filter(Boolean).join(' - ') || '-') + '</td><td><button type="button" class="btn-secondary small" data-user-id="' + html(member.id) + '">Remove</button></td></tr>').join('') +
      '</tbody></table></div>' : '<p class="empty-hint">No members in this class.</p>';
  } catch (error) {
    console.error('Class member load failed', error);
    showMessage('classes-error', error.message || 'Could not load class members.');
  }
}

async function saveClass() {
  clearClassStatus();
  const yearSectionId = $('class-year-section').value;
  const teacherId = $('class-teacher').value;
  const subject = $('class-subject').value.trim();
  if (!yearSectionId || !teacherId || !subject) {
    return showMessage('classes-error', 'Year and section, subject, and teacher are required.');
  }
  const wasEditing = Boolean(editingClassId);
  const result = await performClassAction(
    editingClassId ? '/api/classes/' + encodeURIComponent(editingClassId) : '/api/classes',
    editingClassId ? 'PUT' : 'POST',
    {
      yearSectionId,
      subject,
      teacherId,
      studentIdNumbers: editingClassId ? '' : $('class-student-ids').value,
      includeSectionStudents: !editingClassId && $('class-add-section-students').checked,
    }
  );
  if (result) {
    if (result.report?.length) showEnrollmentReport(result.report);
    else showClassStatus(wasEditing ? 'Class changes saved.' : 'Class created.');
    resetClassForm();
  }
}

async function addClassMembers() {
  clearClassStatus();
  const classId = $('class-member-select').value;
  const studentIdNumbers = $('class-bulk-ids').value;
  if (!classId || !studentIdNumbers.trim()) return showMessage('classes-error', 'Choose a class and enter student ID numbers.');
  const result = await performClassAction(
    '/api/classes/' + encodeURIComponent(classId) + '/members/bulk',
    'POST',
    { studentIdNumbers }
  );
  if (result) {
    $('class-bulk-ids').value = '';
    showEnrollmentReport(result.report);
  }
}

async function performClassAction(url, method, body) {
  try {
    const response = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + (sessionStorage.getItem('edugram_jwt') || '') },
      ...(body ? { body: JSON.stringify(body) } : {}),
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Class update failed');
    $('classes-error')?.classList.add('hidden');
    await refreshClasses();
    return result;
  } catch (error) {
    console.error('Class action failed', error);
    showMessage('classes-error', error.message || 'Could not save class changes.');
    return false;
  }
}

function resetClassForm() {
  editingClassId = null;
  $('class-course').value = '';
  populateAcademicSelect('class-major');
  populateYearSections('class-year-section');
  $('class-subject').value = '';
  $('class-teacher').value = '';
  $('class-student-ids').value = '';
  $('class-add-section-students').checked = false;
  $('class-save').textContent = 'Create class';
  $('class-cancel')?.classList.add('hidden');
}

function showEnrollmentReport(report = []) {
  if (!report.length) {
    $('class-members-report')?.classList.add('hidden');
    return;
  }
  showClassStatus(report.map(item =>
    `${item.studentId}: ${item.status}`
  ).join(' | '));
}

function showClassStatus(message) {
  const status = $('class-members-report');
  if (!status) return;
  status.textContent = message;
  status.classList.remove('hidden');
}

function clearClassStatus() {
  $('class-members-report')?.classList.add('hidden');
  $('classes-error')?.classList.add('hidden');
}

function setupAcademic() {
  $('academic-course-save')?.addEventListener('click', () => saveAcademicEntity('course'));
  $('academic-major-save')?.addEventListener('click', () => saveAcademicEntity('major'));
  $('academic-year-save')?.addEventListener('click', () => saveAcademicEntity('yearSection'));
  $('academic-course-cancel')?.addEventListener('click', () => resetAcademicForm('course'));
  $('academic-major-cancel')?.addEventListener('click', () => resetAcademicForm('major'));
  $('academic-year-cancel')?.addEventListener('click', () => resetAcademicForm('yearSection'));
  $('academic-year-course')?.addEventListener('change', () => populateAcademicSelect(
    'academic-year-major',
    academicCourses.find(course => course.id === $('academic-year-course').value)
  ));
  ['academic-course-code', 'academic-course-name', 'academic-major-name', 'academic-year-name'].forEach(id => {
    $(id)?.addEventListener('input', updateAcademicButtonStates);
  });
  ['academic-major-course', 'academic-year-course', 'academic-year-major'].forEach(id => {
    $(id)?.addEventListener('change', updateAcademicButtonStates);
  });
  $('class-course')?.addEventListener('change', () => populateAcademicSelect(
    'class-major',
    academicCourses.find(course => course.id === $('class-course').value)
  ));
  ['academic-courses-table', 'academic-majors-table', 'academic-years-table'].forEach(id => {
    $(id)?.addEventListener('click', handleAcademicTableAction);
  });
  ['academic-courses-pagination', 'academic-majors-pagination', 'academic-years-pagination'].forEach(id => {
    $(id)?.addEventListener('click', event => {
      const button = event.target.closest('button[data-academic-page]');
      if (!button || button.disabled) return;
      academicPages[button.dataset.academicPage] = Number(button.dataset.page);
      renderAcademicTables();
    });
  });
  updateAcademicButtonStates();
}

async function refreshAcademic(selectedYearMajorId = $('academic-year-major')?.value || '') {
  try {
    const response = await fetch('/api/academic/options');
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Could not load academic options');
    academicCourses = result.courses;
    renderAcademicTables();
    const courseOptions = academicCourses.map(course => ({ id: course.id, label: `${course.code} - ${course.name}` }));
    ['class-course', 'academic-major-course', 'academic-year-course'].forEach(id => {
      const select = $(id);
      if (!select) return;
      const oldValue = select.value;
      select.innerHTML = selectOptions(courseOptions, 'Select course', oldValue);
    });
    const selectedClassMajorId = $('class-major')?.value || '';
    const selectedClassYearSectionId = $('class-year-section')?.value || '';
    populateAcademicSelect('class-major', selectedCourse(), selectedClassMajorId);
    populateYearSections('class-year-section', selectedMajor(), selectedClassYearSectionId);
    populateAcademicSelect('academic-year-major',
      academicCourses.find(course => course.id === $('academic-year-course')?.value), selectedYearMajorId);
    populateAcademicSelect('sp-major',
      academicCourses.find(course => course.id === $('sp-course')?.value), $('sp-major')?.value || '');
    populateYearSections('sp-year-section', null, $('sp-year-section')?.value || '');
    populateAcademicSelect('reg-major', null, $('reg-major')?.value || '');
    populateYearSections('reg-year-section');
    populateAllYearSectionOptions('vp-year-section');
    $('academic-error')?.classList.add('hidden');
    $('class-academic-error')?.classList.add('hidden');
    updateAcademicButtonStates();
    return true;
  } catch (error) {
    console.error('Academic options refresh failed', error);
    showMessage(userRole === 'super_admin' ? 'academic-error' : 'class-academic-error',
      error.message || 'Could not load academic options.');
    return false;
  }
}

function flattenYearSections() {
  return academicCourses.flatMap(course => course.majors.flatMap(major =>
    major.yearSections.map(yearSection => ({
      id: yearSection.id,
      label: `${course.code} - ${major.name} - ${yearSection.name}`,
    }))
  ));
}

function populateAllYearSectionOptions(id) {
  const select = $(id);
  if (!select) return;
  const selected = select.value;
  select.innerHTML = selectOptions(flattenYearSections(), 'Unassigned', selected);
}

function renderAcademicTables() {
  if (userRole !== 'super_admin') return;
  const majors = academicCourses.flatMap(course => course.majors.map(major => ({ ...major, course })));
  const years = academicCourses.flatMap(course => course.majors.flatMap(major =>
    major.yearSections.map(yearSection => ({ ...yearSection, course, major }))
  ));
  renderAcademicPage('courses', academicCourses, 'academic-courses-table', 'academic-courses-pagination', 3, course =>
    `<tr><td>${html(course.code)}</td><td>${html(course.name)}</td><td>
      <button type="button" class="btn-secondary small academic-action-edit" aria-label="Edit course ${html(course.code)}" data-academic-action="edit" data-type="course" data-id="${html(course.id)}">Edit</button>
      <button type="button" class="btn-secondary small academic-action-delete" aria-label="Delete course ${html(course.code)}" data-academic-action="delete" data-type="course" data-id="${html(course.id)}">Delete</button>
    </td></tr>`, 'No courses yet');
  renderAcademicPage('majors', majors, 'academic-majors-table', 'academic-majors-pagination', 3, major =>
    `<tr><td>${html(major.course.code)}</td><td>${html(major.name)}</td><td>
      <button type="button" class="btn-secondary small academic-action-edit" aria-label="Edit major ${html(major.name)}" data-academic-action="edit" data-type="major" data-id="${html(major.id)}">Edit</button>
      <button type="button" class="btn-secondary small academic-action-delete" aria-label="Delete major ${html(major.name)}" data-academic-action="delete" data-type="major" data-id="${html(major.id)}">Delete</button>
    </td></tr>`, 'No majors yet');
  renderAcademicPage('years', years, 'academic-years-table', 'academic-years-pagination', 4, yearSection =>
    `<tr><td>${html(yearSection.course.code)}</td><td>${html(yearSection.major.name)}</td><td>${html(yearSection.name)}</td><td>
      <button type="button" class="btn-secondary small academic-action-edit" aria-label="Edit year and section ${html(yearSection.name)}" data-academic-action="edit" data-type="yearSection" data-id="${html(yearSection.id)}">Edit</button>
      <button type="button" class="btn-secondary small academic-action-delete" aria-label="Delete year and section ${html(yearSection.name)}" data-academic-action="delete" data-type="yearSection" data-id="${html(yearSection.id)}">Delete</button>
    </td></tr>`, 'No year and section entries yet');
}

function renderAcademicPage(key, items, tableId, paginationId, columns, renderRow, emptyMessage) {
  const pageCount = Math.max(1, Math.ceil(items.length / ACADEMIC_PAGE_SIZE));
  academicPages[key] = Math.min(Math.max(1, academicPages[key]), pageCount);
  const startIndex = (academicPages[key] - 1) * ACADEMIC_PAGE_SIZE;
  const pageItems = items.slice(startIndex, startIndex + ACADEMIC_PAGE_SIZE);
  const table = $(tableId);
  if (table) {
    table.innerHTML = pageItems.length
      ? pageItems.map(renderRow).join('')
      : `<tr><td colspan="${columns}" class="academic-empty">${emptyMessage}</td></tr>`;
  }
  const pagination = $(paginationId);
  if (!pagination) return;
  const start = items.length ? startIndex + 1 : 0;
  const end = Math.min(startIndex + ACADEMIC_PAGE_SIZE, items.length);
  pagination.innerHTML = `<span>Showing ${start}-${end} of ${items.length}</span><div class="pagination-buttons"><button type="button" class="btn-secondary small" data-academic-page="${key}" data-page="${academicPages[key] - 1}" ${academicPages[key] <= 1 ? 'disabled' : ''}>Previous</button><span>Page ${academicPages[key]} of ${pageCount}</span><button type="button" class="btn-secondary small" data-academic-page="${key}" data-page="${academicPages[key] + 1}" ${academicPages[key] >= pageCount ? 'disabled' : ''}>Next</button></div>`;
}

function academicEndpoint(type) {
  return `/api/academic/${type === 'yearSection' ? 'year-sections' : `${type}s`}`;
}

async function saveAcademicEntity(type) {
  $('academic-success')?.classList.add('hidden');
  $('academic-error')?.classList.add('hidden');
  const id = editingAcademic?.type === type ? editingAcademic.id : null;
  let body;
  if (type === 'course') {
    body = { code: $('academic-course-code').value.trim().toUpperCase(), name: $('academic-course-name').value.trim() };
  } else if (type === 'major') {
    body = { courseId: $('academic-major-course').value, name: $('academic-major-name').value.trim() };
  } else {
    body = { majorId: $('academic-year-major').value, name: $('academic-year-name').value.trim() };
  }
  if ((type === 'course' && (!body.code || !body.name))
    || (type === 'major' && (!body.courseId || !body.name))
    || (type === 'yearSection' && (!body.majorId || !body.name))) {
    showMessage('academic-error', 'Complete all required fields before saving.');
    return;
  }
  await performAcademicAction(`${academicEndpoint(type)}${id ? `/${encodeURIComponent(id)}` : ''}`, id ? 'PUT' : 'POST', body, type);
}

async function performAcademicAction(url, method, body, type) {
  try {
    const response = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${sessionStorage.getItem('edugram_jwt') || ''}` },
      body: JSON.stringify(body),
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Academic setup update failed');
    $('academic-error')?.classList.add('hidden');
    $('academic-success')?.classList.add('hidden');
    resetAcademicForm(type);
    if (type === 'major' && body.courseId) $('academic-year-course').value = body.courseId;
    if (!await refreshAcademic()) return;
    if (type === 'major' && result.id) {
      $('academic-year-major').value = String(result.id);
      updateAcademicButtonStates();
    }
    await refreshClasses();
    showMessage('academic-success', `${type === 'yearSection' ? 'Year and section' : type[0].toUpperCase() + type.slice(1)} ${method === 'PUT' ? 'updated' : 'added'} successfully.`);
  } catch (error) {
    console.error('Academic setup action failed', error);
    showMessage('academic-error', error.message || 'Could not save academic changes.');
  }
}

async function handleAcademicTableAction(event) {
  const button = event.target.closest('button[data-academic-action]');
  if (!button) return;
  const { type, id } = button.dataset;
  const base = academicEndpoint(type);
  if (button.dataset.academicAction === 'delete') {
    if (!confirm(`Delete this ${type === 'yearSection' ? 'year and section' : type}?`)) return;
    $('academic-success')?.classList.add('hidden');
    $('academic-error')?.classList.add('hidden');
    try {
      const response = await fetch(`${base}/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${sessionStorage.getItem('edugram_jwt') || ''}` },
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Could not delete academic entry');
      $('academic-success')?.classList.add('hidden');
      if (!await refreshAcademic()) return;
      await refreshClasses();
      showMessage('academic-success', `${type === 'yearSection' ? 'Year and section' : type[0].toUpperCase() + type.slice(1)} deleted successfully.`);
    } catch (error) {
      console.error('Academic delete failed', error);
      showMessage('academic-error', error.message || 'Could not delete academic entry.');
    }
    return;
  }
  const course = academicCourses.find(item => item.id === id);
  const major = academicCourses.flatMap(item => item.majors).find(item => item.id === id);
  const yearSection = academicCourses.flatMap(item => item.majors.flatMap(entry => entry.yearSections))
    .find(item => item.id === id);
  editingAcademic = { type, id };
  if (type === 'course' && course) {
    $('academic-course-code').value = course.code;
    $('academic-course-name').value = course.name;
  } else if (type === 'major' && major) {
    const parent = academicCourses.find(item => item.majors.some(entry => entry.id === id));
    $('academic-major-course').value = parent.id;
    $('academic-major-name').value = major.name;
  } else if (type === 'yearSection' && yearSection) {
    const parentMajor = academicCourses.flatMap(item => item.majors).find(item =>
      item.yearSections.some(entry => entry.id === id)
    );
    const parentCourse = academicCourses.find(item => item.majors.includes(parentMajor));
    $('academic-year-course').value = parentCourse.id;
    populateAcademicSelect('academic-year-major', parentCourse);
    $('academic-year-major').value = parentMajor.id;
    $('academic-year-name').value = yearSection.name;
  }
  setAcademicButtonLabels(type, true);
  updateAcademicButtonStates();
}

function setAcademicButtonLabels(type, editing) {
  const prefix = type === 'yearSection' ? 'year' : type;
  $(`academic-${prefix}-save`).textContent = editing
    ? (type === 'yearSection' ? 'Save year and section' : `Save ${type}`)
    : (type === 'yearSection' ? 'Add year and section' : `Add ${type}`);
  $(`academic-${prefix}-cancel`)?.classList.toggle('hidden', !editing);
}

function resetAcademicForm(type) {
  if (editingAcademic?.type === type) editingAcademic = null;
  const prefix = type === 'yearSection' ? 'year' : type;
  if (type === 'course') {
    $('academic-course-code').value = '';
    $('academic-course-name').value = '';
  } else if (type === 'major') {
    $('academic-major-name').value = '';
  } else {
    $('academic-year-name').value = '';
  }
  setAcademicButtonLabels(type, false);
  updateAcademicButtonStates();
}

function updateAcademicButtonStates() {
  if ($('academic-course-save')) {
    $('academic-course-save').disabled = !($('academic-course-code')?.value.trim() && $('academic-course-name')?.value.trim());
  }
  if ($('academic-major-save')) {
    $('academic-major-save').disabled = !($('academic-major-course')?.value && $('academic-major-name')?.value.trim());
  }
  if ($('academic-year-save')) {
    $('academic-year-save').disabled = !($('academic-year-major')?.value && $('academic-year-name')?.value.trim());
  }
}

function showMessage(id, message) {
  const el = $(id);
  if (!el) return;
  el.textContent = message;
  el.classList.remove('hidden');
}

function logout() {
  sessionStorage.clear();
  window.location.href = 'index.php';
}

window.logout = logout;
document.addEventListener('DOMContentLoaded', initAdminDashboard);
