'use strict';

const mysql = require('mysql2/promise');

const DEFAULT_DATABASE_NAME = 'edugram_login_db';
const ENV_DATABASE_NAME = String(
  process.env.LOGIN_DB_NAME ?? process.env.MYSQL_DATABASE ?? DEFAULT_DATABASE_NAME
).trim();
const DATABASE_NAME = ENV_DATABASE_NAME === 'edugram_database' ? DEFAULT_DATABASE_NAME : ENV_DATABASE_NAME;
let pool;

function getDb() {
  if (!DATABASE_NAME || DATABASE_NAME !== DEFAULT_DATABASE_NAME) {
    throw new Error(`LOGIN_DB_NAME must be set to ${DEFAULT_DATABASE_NAME}`);
  }
  if (!pool) {
    pool = mysql.createPool({
      host: process.env.LOGIN_DB_HOST || process.env.MYSQL_HOST || '127.0.0.1',
      port: Number(process.env.LOGIN_DB_PORT || process.env.MYSQL_PORT || 3306),
      user: process.env.LOGIN_DB_USER || process.env.MYSQL_USER || 'root',
      password: process.env.LOGIN_DB_PASSWORD ?? process.env.MYSQL_PASSWORD ?? '',
      database: DATABASE_NAME,
      waitForConnections: true,
      connectionLimit: 5,
      supportBigNumbers: true,
      bigNumberStrings: true,
    });
  }
  return pool;
}

module.exports = { DATABASE_NAME, getDb };
