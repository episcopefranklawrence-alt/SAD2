'use strict';

const { getDb } = require('./db');

const VALID_ROLES = new Set(['student', 'teacher', 'admin', 'super_admin']);

function normalizeUser(row) {
  if (!row) return null;
  return {
    ...row,
    id: String(row.id),
    _dbUserId: String(row._dbUserId),
  };
}

function userSelect(includeLegacyId = false) {
  return `
    SELECT
      CAST(u.user_id AS CHAR) AS id,
      CAST(u.user_id AS CHAR) AS _dbUserId,
      u.email,
      ${includeLegacyId ? 'u.app_user_id AS legacyId,' : ''}
      u.phone,
      u.password_hash AS passwordHash,
      u.first_name AS firstName,
      u.middle_name AS middleName,
      u.last_name AS lastName,
      u.school_id_number AS studentId,
      CAST(u.year_section_id AS CHAR) AS yearSectionId,
      year_section.year_section_name AS yearSectionName,
      CAST(major.major_id AS CHAR) AS majorId,
      major.major_name AS majorName,
      CAST(course.course_id AS CHAR) AS courseId,
      course.course_code AS courseCode,
      course.course_name AS courseName,
      u.account_status AS accountStatus,
      u.failed_login_count AS failedLoginCount,
      u.locked_until AS lockedUntil,
      r.role_name AS role,
      u.created_at AS createdAt,
      u.updated_at AS updatedAt
    FROM users u
    JOIN roles r ON r.role_id = u.role_id
    LEFT JOIN year_sections year_section ON year_section.year_section_id = u.year_section_id
    LEFT JOIN majors major ON major.major_id = year_section.major_id
    LEFT JOIN courses course ON course.course_id = major.course_id
  `;
}

function requireId(id) {
  const value = String(id ?? '');
  if (!/^[1-9]\d*$/.test(value)) throw new TypeError('A valid MySQL user_id is required');
  return value;
}

async function initMySql() {
  const db = getDb();
  await db.query('SELECT 1');
  await db.query(`CREATE TABLE IF NOT EXISTS coursework_records (
    record_type ENUM('assignment','submission','draft') NOT NULL,
    record_id VARCHAR(191) NOT NULL,
    owner_id BIGINT UNSIGNED NULL,
    parent_id VARCHAR(191) NULL,
    payload LONGTEXT NOT NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (record_type, record_id),
    KEY coursework_owner (record_type, owner_id),
    KEY coursework_parent (record_type, parent_id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);
  const [columns] = await db.execute(`
    SELECT COLUMN_NAME FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'middle_name'
  `);
  if (!columns.length) await db.query('ALTER TABLE users ADD COLUMN middle_name VARCHAR(100) NULL AFTER first_name');
  return true;
}

async function listCourseworkRecords() {
  const [rows] = await getDb().query('SELECT record_type AS type, record_id AS id, payload FROM coursework_records');
  const data = { users: [], assignments: [], submissions: [], drafts: {} };
  for (const row of rows) {
    let value;
    try { value = JSON.parse(row.payload); } catch { continue; }
    if (row.type === 'assignment') data.assignments.push(value);
    else if (row.type === 'submission') data.submissions.push(value);
    else if (row.type === 'draft') data.drafts[row.id] = value;
  }
  return data;
}

function courseworkRows(data) {
  return [
    ...(data.assignments || []).map(value => ({ type: 'assignment', id: String(value.id), owner: value.createdBy, parent: null, value })),
    ...(data.submissions || []).map(value => ({ type: 'submission', id: String(value.id), owner: value.studentId, parent: value.assignmentId, value })),
    ...Object.entries(data.drafts || {}).map(([id, value]) => ({ type: 'draft', id, owner: id.split(':')[0], parent: id.slice(id.indexOf(':') + 1), value })),
  ];
}

async function replaceCourseworkRecords(data, previousData = null) {
  const connection = await getDb().getConnection();
  try {
    await connection.beginTransaction();
    const rows = courseworkRows(data);
    const nextKeys = new Set(rows.map(row => `${row.type}:${row.id}`));
    const previousRows = previousData ? courseworkRows(previousData) : [];
    for (const row of previousRows) {
      if (!nextKeys.has(`${row.type}:${row.id}`)) {
        await connection.execute('DELETE FROM coursework_records WHERE record_type = ? AND record_id = ?', [row.type, row.id]);
      }
    }
    for (const row of rows) {
      const previous = previousRows.find(item => item.type === row.type && item.id === row.id);
      if (previous && JSON.stringify(previous.value) === JSON.stringify(row.value)) continue;
      await connection.execute(
        'INSERT INTO coursework_records (record_type, record_id, owner_id, parent_id, payload) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE owner_id = VALUES(owner_id), parent_id = VALUES(parent_id), payload = VALUES(payload)',
        [row.type, String(row.id), /^[1-9]\d*$/.test(String(row.owner)) ? String(row.owner) : null, row.parent == null ? null : String(row.parent), JSON.stringify(row.value)]
      );
    }
    await connection.commit();
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function courseworkRecordCount() {
  const [rows] = await getDb().query('SELECT COUNT(*) AS count FROM coursework_records');
  return Number(rows[0].count);
}

async function listUsers(options = {}) {
  const [rows] = await getDb().query(`${userSelect(options.includeLegacyId)} ORDER BY u.created_at, u.user_id`);
  return rows.map(normalizeUser);
}

async function findUserByEmail(email) {
  const [rows] = await getDb().execute(
    `${userSelect()} WHERE LOWER(u.email) = LOWER(?) LIMIT 1`,
    [email]
  );
  return normalizeUser(rows[0]);
}

async function findUserByIdentifier(identifier) {
  const [rows] = await getDb().execute(
    `${userSelect()} WHERE LOWER(u.email) = LOWER(?) OR u.phone = ? LIMIT 1`,
    [identifier, identifier]
  );
  return normalizeUser(rows[0]);
}

async function findUserById(id) {
  const [rows] = await getDb().execute(`${userSelect()} WHERE u.user_id = ? LIMIT 1`, [requireId(id)]);
  return normalizeUser(rows[0]);
}

async function createUser(user) {
  if (!VALID_ROLES.has(user.role)) throw new TypeError('Invalid role');
  const db = getDb();
  const [result] = await db.execute(`
    INSERT INTO users (
      role_id, email, phone, password_hash,
      first_name, middle_name, last_name, school_id_number, year_section_id, account_status,
      terms_accepted_at
    )
    SELECT r.role_id, ?, ?, ?, ?, ?, ?, ?, ?, 'active', CURRENT_TIMESTAMP
    FROM roles r
    WHERE r.role_name = ?
  `, [
    user.email,
    user.phone || null,
    user.passwordHash,
    user.firstName,
    user.middleName || null,
    user.lastName,
    user.studentId || null,
    user.yearSectionId || null,
    user.role,
  ]);

  if (result.affectedRows !== 1) throw new Error(`Role "${user.role}" is missing from roles`);
  return String(result.insertId);
}

async function updateUserPassword(id, passwordHash, auditInfo) {
  const db = getDb();
  const userId = requireId(id);
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const [rows] = await connection.execute(
      'SELECT password_hash FROM users WHERE user_id = ? FOR UPDATE',
      [userId]
    );
    if (!rows[0]) {
      await connection.rollback();
      return false;
    }
    await connection.execute(
      'INSERT INTO password_history (user_id, password_hash) VALUES (?, ?)',
      [userId, passwordHash]
    );
    const [result] = await connection.execute(
      `UPDATE users
       SET password_hash = ?, password_changed_at = CURRENT_TIMESTAMP,
           failed_login_count = 0, locked_until = NULL
       WHERE user_id = ?`,
      [passwordHash, userId]
    );
    if (auditInfo) {
      await insertAudit(
        connection,
        auditInfo.actorId,
        auditInfo.eventType,
        auditInfo.description,
        auditInfo.ipAddress
      );
    }
    await connection.commit();
    return result.affectedRows > 0;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function updateUserRole(id, role, auditInfo) {
  if (!VALID_ROLES.has(role)) throw new TypeError('Invalid role');
  const db = getDb();
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const userId = requireId(id);
    const [users] = await connection.execute(
      `SELECT r.role_name
       FROM users u JOIN roles r ON r.role_id = u.role_id
       WHERE u.user_id = ? FOR UPDATE`,
      [userId]
    );
    if (!users[0]) {
      await connection.rollback();
      return false;
    }
    const [roles] = await connection.execute(
      'SELECT role_id FROM roles WHERE role_name = ?',
      [role]
    );
    if (!roles[0]) throw new Error(`Role "${role}" is missing from roles`);
    await connection.execute(
      'UPDATE users SET role_id = ? WHERE user_id = ?',
      [roles[0].role_id, userId]
    );
    if (role !== 'student') {
      const [enrollments] = await connection.execute(
        'SELECT class_id FROM enrollments WHERE student_id = ? FOR UPDATE',
        [userId]
      );
      await connection.execute('DELETE FROM enrollments WHERE student_id = ?', [userId]);
      for (const enrollment of enrollments) {
        await insertAudit(
          connection,
          auditInfo?.actorId,
          'class_member_removed',
          `Removed user ${userId} from class ${enrollment.class_id} due to role change`,
          auditInfo?.ipAddress
        );
      }
    }
    if (auditInfo) {
      await insertAudit(
        connection,
        auditInfo.actorId,
        'role_changed',
        `Changed user ${userId} role to ${role}`,
        auditInfo.ipAddress
      );
    }
    await connection.commit();
    return true;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function updateUserStatus(id, status, auditInfo) {
  if (!['active', 'locked', 'suspended'].includes(status)) throw new TypeError('Invalid account status');
  const connection = await getDb().getConnection();
  try {
    await connection.beginTransaction();
    const userId = requireId(id);
    const [rows] = await connection.execute('SELECT user_id FROM users WHERE user_id = ? FOR UPDATE', [userId]);
    if (!rows[0]) {
      await connection.rollback();
      return false;
    }
    await connection.execute(`
      UPDATE users
      SET account_status = ?,
          failed_login_count = CASE WHEN ? = 'active' THEN 0 ELSE failed_login_count END,
          locked_until = CASE WHEN ? = 'active' THEN NULL ELSE locked_until END
      WHERE user_id = ?
    `, [status, status, status, userId]);
    if (auditInfo) {
      await insertAudit(connection, auditInfo.actorId, auditInfo.eventType, auditInfo.description, auditInfo.ipAddress);
    }
    await connection.commit();
    return true;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function deleteUser(id, auditInfo) {
  const connection = await getDb().getConnection();
  try {
    await connection.beginTransaction();
    const userId = requireId(id);
    const [rows] = await connection.execute('SELECT user_id FROM users WHERE user_id = ? FOR UPDATE', [userId]);
    if (!rows[0]) {
      await connection.rollback();
      return false;
    }
    const [enrollments] = await connection.execute(
      'SELECT class_id FROM enrollments WHERE student_id = ? FOR UPDATE',
      [userId]
    );
    await connection.execute('DELETE FROM users WHERE user_id = ?', [userId]);
    for (const enrollment of enrollments) {
      await insertAudit(
        connection,
        auditInfo.actorId,
        'class_member_removed',
        `Removed deleted user ${userId} from class ${enrollment.class_id}`,
        auditInfo.ipAddress
      );
    }
    await insertAudit(
      connection,
      auditInfo.actorId,
      'user_deleted',
      `User ${auditInfo.actorId} deleted user ${userId}`,
      auditInfo.ipAddress
    );
    await connection.commit();
    return true;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function recordLoginAttempt({ userId, identifier, success, ipAddress }) {
  await getDb().execute(`
    INSERT INTO login_attempts (
      user_id, identifier_used, ip_address, was_successful, failure_reason
    ) VALUES (?, ?, ?, ?, ?)
  `, [
    userId ? requireId(userId) : null,
    String(identifier || '(empty)').slice(0, 255),
    String(ipAddress || '0.0.0.0').slice(0, 45),
    success ? 1 : 0,
    success ? null : 'invalid_credentials',
  ]);
}

async function recordAuditLog({ userId, eventType, description, ipAddress }) {
  await getDb().execute(`
    INSERT INTO audit_logs (user_id, event_type, description, ip_address)
    VALUES (?, ?, ?, ?)
  `, [
    userId ? requireId(userId) : null,
    String(eventType).slice(0, 50),
    description ? String(description).slice(0, 255) : null,
    ipAddress ? String(ipAddress).slice(0, 45) : null,
  ]);
}

async function listAcademicOptions() {
  const [rows] = await getDb().query(`
    SELECT CAST(course.course_id AS CHAR) AS courseId,
           course.course_code AS courseCode, course.course_name AS courseName,
           CAST(major.major_id AS CHAR) AS majorId, major.major_name AS majorName,
           CAST(year_section.year_section_id AS CHAR) AS yearSectionId,
           year_section.year_section_name AS yearSectionName
    FROM courses course
    LEFT JOIN majors major ON major.course_id = course.course_id
    LEFT JOIN year_sections year_section ON year_section.major_id = major.major_id
    ORDER BY course.course_code, major.major_name, year_section.year_section_name
  `);
  const courses = new Map();
  for (const row of rows) {
    if (!courses.has(row.courseId)) {
      courses.set(row.courseId, {
        id: row.courseId,
        code: row.courseCode,
        name: row.courseName,
        majors: [],
      });
    }
    if (!row.majorId) continue;
    const course = courses.get(row.courseId);
    let major = course.majors.find(item => item.id === row.majorId);
    if (!major) {
      major = { id: row.majorId, name: row.majorName, yearSections: [] };
      course.majors.push(major);
    }
    if (row.yearSectionId) {
      major.yearSections.push({ id: row.yearSectionId, name: row.yearSectionName });
    }
  }
  return [...courses.values()];
}

async function findOrCreateYearSection(courseId, majorId, name) {
  const normalizedCourseId = requireId(courseId);
  const normalizedMajorId = requireId(majorId);
  const normalizedName = String(name ?? '').trim().replace(/\s+/g, ' ');
  if (!normalizedName || normalizedName.length > 20) return null;

  const connection = await getDb().getConnection();
  try {
    await connection.beginTransaction();
    const [majors] = await connection.execute(
      'SELECT major_id FROM majors WHERE major_id = ? AND course_id = ? FOR UPDATE',
      [normalizedMajorId, normalizedCourseId]
    );
    if (!majors[0]) {
      await connection.rollback();
      return null;
    }

    const [existing] = await connection.execute(
      'SELECT CAST(year_section_id AS CHAR) AS id FROM year_sections WHERE major_id = ? AND LOWER(year_section_name) = LOWER(?) LIMIT 1 FOR UPDATE',
      [normalizedMajorId, normalizedName]
    );
    if (existing[0]) {
      await connection.commit();
      return existing[0].id;
    }

    const [result] = await connection.execute(
      'INSERT INTO year_sections (major_id, year_section_name) VALUES (?, ?)',
      [normalizedMajorId, normalizedName]
    );
    await connection.commit();
    return String(result.insertId);
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function saveAcademicEntity(type, values, actorId, ipAddress, id = null) {
  const configs = {
    course: {
      table: 'courses',
      idColumn: 'course_id',
      fields: ['course_code', 'course_name'],
      values: () => [values.code, values.name],
      label: `course ${values.code}`,
    },
    major: {
      table: 'majors',
      idColumn: 'major_id',
      fields: ['course_id', 'major_name'],
      values: () => [requireId(values.courseId), values.name],
      label: `major ${values.name}`,
    },
    yearSection: {
      table: 'year_sections',
      idColumn: 'year_section_id',
      fields: ['major_id', 'year_section_name'],
      values: () => [requireId(values.majorId), values.name],
      label: `year and section ${values.name}`,
    },
  };
  const config = configs[type];
  if (!config) throw new TypeError('Invalid academic entity type');
  const connection = await getDb().getConnection();
  try {
    await connection.beginTransaction();
    let entityId;
    if (id) {
      entityId = requireId(id);
      const [existing] = await connection.execute(
        `SELECT ${config.idColumn} FROM ${config.table} WHERE ${config.idColumn} = ? FOR UPDATE`,
        [entityId]
      );
      if (!existing[0]) {
        await connection.rollback();
        return null;
      }
      await connection.execute(
        `UPDATE ${config.table} SET ${config.fields.map(field => `${field} = ?`).join(', ')} WHERE ${config.idColumn} = ?`,
        [...config.values(), entityId]
      );
      await insertAudit(connection, actorId, `${type}_updated`, `Updated ${config.label}`, ipAddress);
    } else {
      const [result] = await connection.execute(
        `INSERT INTO ${config.table} (${config.fields.join(', ')}) VALUES (${config.fields.map(() => '?').join(', ')})`,
        config.values()
      );
      entityId = String(result.insertId);
      await insertAudit(connection, actorId, `${type}_created`, `Created ${config.label}`, ipAddress);
    }
    await connection.commit();
    return entityId;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function deleteAcademicEntity(type, id, actorId, ipAddress) {
  const configs = {
    course: {
      table: 'courses',
      idColumn: 'course_id',
      nameColumn: 'course_name',
      usage: `SELECT COUNT(DISTINCT major.major_id) AS majorCount,
                     COUNT(DISTINCT class.class_id) AS classCount
              FROM majors major
              LEFT JOIN year_sections year_section ON year_section.major_id = major.major_id
              LEFT JOIN classes class ON class.year_section_id = year_section.year_section_id
              WHERE major.course_id = ?`,
      describe: row => {
        const uses = [];
        if (Number(row.majorCount)) uses.push(`${row.majorCount} major${Number(row.majorCount) === 1 ? '' : 's'}`);
        if (Number(row.classCount)) uses.push(`${row.classCount} class${Number(row.classCount) === 1 ? '' : 'es'}`);
        return uses;
      },
    },
    major: {
      table: 'majors',
      idColumn: 'major_id',
      nameColumn: 'major_name',
      usage: `SELECT COUNT(DISTINCT year_section.year_section_id) AS yearSectionCount,
                     COUNT(DISTINCT class.class_id) AS classCount
              FROM year_sections year_section
              LEFT JOIN classes class ON class.year_section_id = year_section.year_section_id
              WHERE year_section.major_id = ?`,
      describe: row => {
        const uses = [];
        if (Number(row.yearSectionCount)) uses.push(`${row.yearSectionCount} year/section${Number(row.yearSectionCount) === 1 ? '' : 's'}`);
        if (Number(row.classCount)) uses.push(`${row.classCount} class${Number(row.classCount) === 1 ? '' : 'es'}`);
        return uses;
      },
    },
    yearSection: {
      table: 'year_sections',
      idColumn: 'year_section_id',
      nameColumn: 'year_section_name',
      usage: `SELECT COUNT(DISTINCT class.class_id) AS classCount,
                     COUNT(DISTINCT student_user.user_id) AS userCount
              FROM year_sections year_section
              LEFT JOIN classes class ON class.year_section_id = year_section.year_section_id
              LEFT JOIN users student_user ON student_user.year_section_id = year_section.year_section_id
              WHERE year_section.year_section_id = ?`,
      describe: row => {
        const uses = [];
        if (Number(row.classCount)) uses.push(`${row.classCount} class${Number(row.classCount) === 1 ? '' : 'es'}`);
        if (Number(row.userCount)) uses.push(`${row.userCount} user${Number(row.userCount) === 1 ? '' : 's'}`);
        return uses;
      },
    },
  };
  const config = configs[type];
  if (!config) throw new TypeError('Invalid academic entity type');
  const connection = await getDb().getConnection();
  try {
    await connection.beginTransaction();
    const entityId = requireId(id);
    const [entities] = await connection.execute(
      `SELECT ${config.nameColumn} AS name FROM ${config.table} WHERE ${config.idColumn} = ? FOR UPDATE`,
      [entityId]
    );
    if (!entities[0]) {
      await connection.rollback();
      return { deleted: false };
    }
    const [usageRows] = await connection.execute(config.usage, [entityId]);
    const uses = config.describe(usageRows[0]);
    if (uses.length) {
      await connection.rollback();
      return { deleted: false, inUse: uses };
    }
    await connection.execute(
      `DELETE FROM ${config.table} WHERE ${config.idColumn} = ?`,
      [entityId]
    );
    await insertAudit(
      connection,
      actorId,
      `${type}_deleted`,
      `Deleted ${type} ${entities[0].name}`,
      ipAddress
    );
    await connection.commit();
    return { deleted: true };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function updateUserProfile(id, profile, passwordHash, auditInfo) {
  const connection = await getDb().getConnection();
  try {
    await connection.beginTransaction();
    const userId = requireId(id);
    const [rows] = await connection.execute(
      'SELECT user_id, year_section_id FROM users WHERE user_id = ? FOR UPDATE',
      [userId]
    );
    if (!rows[0]) {
      await connection.rollback();
      return false;
    }
    await connection.execute(`
      UPDATE users
      SET email = ?, first_name = ?, middle_name = ?, last_name = ?, phone = ?,
          school_id_number = ?, year_section_id = ?
      WHERE user_id = ?
    `, [
      profile.email,
      profile.firstName,
      profile.middleName || null,
      profile.lastName,
      profile.phone || null,
      profile.studentId || null,
      profile.yearSectionId || null,
      userId,
    ]);
    if (passwordHash) {
      await connection.execute(
        'INSERT INTO password_history (user_id, password_hash) VALUES (?, ?)',
        [userId, passwordHash]
      );
      await connection.execute(`
        UPDATE users
        SET password_hash = ?, password_changed_at = CURRENT_TIMESTAMP,
            failed_login_count = 0, locked_until = NULL
        WHERE user_id = ?
      `, [passwordHash, userId]);
    }
    await insertAudit(connection, auditInfo.actorId, auditInfo.eventType, auditInfo.description, auditInfo.ipAddress);
    if (String(rows[0].year_section_id || '') !== String(profile.yearSectionId || '')) {
      await insertAudit(
        connection,
        auditInfo.actorId,
        profile.yearSectionId ? 'year_section_assigned' : 'year_section_removed',
        profile.yearSectionId
          ? `Assigned user ${userId} to year and section ${profile.yearSectionId}`
          : `Removed user ${userId} from their year and section`,
        auditInfo.ipAddress
      );
    }
    await connection.commit();
    return true;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function findClass(id) {
  const [rows] = await getDb().execute(`
    SELECT CAST(c.class_id AS CHAR) AS id,
           CAST(c.year_section_id AS CHAR) AS yearSectionId,
           CAST(c.teacher_id AS CHAR) AS teacherId, c.subject,
           course.course_code AS courseCode, course.course_name AS courseName,
           major.major_name AS majorName,
           year_section.year_section_name AS yearSectionName
    FROM classes c
    JOIN year_sections year_section ON year_section.year_section_id = c.year_section_id
    JOIN majors major ON major.major_id = year_section.major_id
    JOIN courses course ON course.course_id = major.course_id
    WHERE c.class_id = ?
  `, [requireId(id)]);
  return rows[0] || null;
}

async function yearSectionExists(id) {
  const [rows] = await getDb().execute(`
    SELECT 1 FROM year_sections WHERE year_section_id = ? LIMIT 1
  `, [requireId(id)]);
  return rows.length > 0;
}

async function academicNameExists(type, values, excludingId = null) {
  const queries = {
    course: () => ({
      sql: 'SELECT 1 FROM courses WHERE course_code = ? AND (? IS NULL OR course_id <> ?) LIMIT 1',
      params: [values.code, excludingId, excludingId],
    }),
    major: () => ({
      sql: 'SELECT 1 FROM majors WHERE course_id = ? AND LOWER(major_name) = LOWER(?) AND (? IS NULL OR major_id <> ?) LIMIT 1',
      params: [requireId(values.courseId), values.name, excludingId, excludingId],
    }),
    yearSection: () => ({
      sql: 'SELECT 1 FROM year_sections WHERE major_id = ? AND LOWER(year_section_name) = LOWER(?) AND (? IS NULL OR year_section_id <> ?) LIMIT 1',
      params: [requireId(values.majorId), values.name, excludingId, excludingId],
    }),
  };
  const getQuery = queries[type];
  if (!getQuery) throw new TypeError('Invalid academic entity type');
  const query = getQuery();
  const [rows] = await getDb().execute(query.sql, query.params);
  return rows.length > 0;
}

async function academicParentExists(type, id) {
  const config = {
    major: { table: 'courses', idColumn: 'course_id' },
    yearSection: { table: 'majors', idColumn: 'major_id' },
  }[type];
  if (!config) throw new TypeError('Invalid academic entity type');
  const [rows] = await getDb().execute(
    `SELECT 1 FROM ${config.table} WHERE ${config.idColumn} = ? LIMIT 1`,
    [requireId(id)]
  );
  return rows.length > 0;
}

async function countClassesForTeacher(teacherId) {
  const [rows] = await getDb().execute(
    'SELECT COUNT(*) AS classCount FROM classes WHERE teacher_id = ?',
    [requireId(teacherId)]
  );
  return Number(rows[0]?.classCount || 0);
}

async function listClasses({ role, userId }) {
  const accessFilter = role === 'student'
    ? `WHERE EXISTS (
         SELECT 1 FROM enrollments own
         WHERE own.class_id = c.class_id AND own.student_id = ?
       )`
    : role === 'teacher'
      ? 'WHERE c.teacher_id = ?'
    : '';
  const params = role === 'student' || role === 'teacher' ? [requireId(userId)] : [];
  const [rows] = await getDb().execute(`
    SELECT CAST(c.class_id AS CHAR) AS id,
           CAST(c.year_section_id AS CHAR) AS yearSectionId,
           course.course_code AS courseCode, course.course_name AS courseName,
           major.major_name AS majorName,
           year_section.year_section_name AS yearSectionName,
           c.subject,
           CAST(c.teacher_id AS CHAR) AS teacherId,
           CONCAT_WS(' ', NULLIF(t.first_name, ''), NULLIF(t.middle_name, ''), NULLIF(t.last_name, '')) AS teacherName,
           COUNT(e.student_id) AS memberCount
    FROM classes c
    JOIN users t ON t.user_id = c.teacher_id
    JOIN year_sections year_section ON year_section.year_section_id = c.year_section_id
    JOIN majors major ON major.major_id = year_section.major_id
    JOIN courses course ON course.course_id = major.course_id
    LEFT JOIN enrollments e ON e.class_id = c.class_id
    ${accessFilter}
    GROUP BY c.class_id, c.year_section_id, course.course_code,
             course.course_name, major.major_name, year_section.year_section_name,
             c.subject, c.teacher_id, t.first_name, t.middle_name, t.last_name
    ORDER BY course.course_code, major.major_name,
             year_section.year_section_name, c.subject, c.class_id
  `, params);
  return rows;
}

async function listClassMembers(classId) {
  const [rows] = await getDb().execute(`
    SELECT CAST(u.user_id AS CHAR) AS id, u.first_name AS firstName,
           u.middle_name AS middleName, u.last_name AS lastName, u.school_id_number AS studentId,
           u.email, r.role_name AS role,
           year_section.year_section_name AS yearSectionName,
           major.major_name AS majorName, course.course_name AS courseName,
           course.course_code AS courseCode
    FROM enrollments e
    JOIN users u ON u.user_id = e.student_id
    JOIN roles r ON r.role_id = u.role_id
    LEFT JOIN year_sections year_section ON year_section.year_section_id = u.year_section_id
    LEFT JOIN majors major ON major.major_id = year_section.major_id
    LEFT JOIN courses course ON course.course_id = major.course_id
    WHERE e.class_id = ?
    ORDER BY u.last_name, u.first_name, u.user_id
  `, [requireId(classId)]);
  return rows;
}

async function isStudentEnrolled(classId, studentId) {
  const [rows] = await getDb().execute(
    'SELECT 1 FROM enrollments WHERE class_id = ? AND student_id = ? LIMIT 1',
    [requireId(classId), requireId(studentId)]
  );
  return rows.length > 0;
}

function parseStudentIdNumbers(value) {
  if (typeof value !== 'string') return [];
  return [...new Set(value.split(/[\s,]+/).map(id => id.trim()).filter(Boolean))];
}

async function enrollStudentNumbers(connection, classId, studentIds, actorId, ipAddress) {
  const report = [];
  for (const studentId of studentIds) {
    const [rows] = await connection.execute(`
      SELECT u.user_id, r.role_name AS role
      FROM users u JOIN roles r ON r.role_id = u.role_id
      WHERE u.school_id_number = ? FOR UPDATE
    `, [studentId]);
    if (!rows[0]) {
      report.push({ studentId, status: 'not found' });
      continue;
    }
    if (rows[0].role !== 'student') {
      report.push({ studentId, status: 'not a student' });
      continue;
    }
    const userId = requireId(rows[0].user_id);
    const [existing] = await connection.execute(
      'SELECT 1 FROM enrollments WHERE class_id = ? AND student_id = ? FOR UPDATE',
      [classId, userId]
    );
    if (existing.length) {
      report.push({ studentId, status: 'already in this class' });
      continue;
    }
    await connection.execute(
      'INSERT INTO enrollments (class_id, student_id) VALUES (?, ?)',
      [classId, userId]
    );
    await insertAudit(
      connection,
      actorId,
      'class_member_added',
      `Enrolled user ${userId} in class ${classId}`,
      ipAddress
    );
    report.push({ studentId, status: 'added' });
  }
  return report;
}

async function enrollAllStudentsInYearSection(connection, classId, yearSectionId, actorId, ipAddress) {
  const [students] = await connection.execute(`
    SELECT u.user_id
    FROM users u JOIN roles r ON r.role_id = u.role_id
    WHERE r.role_name = 'student' AND u.year_section_id = ?
    ORDER BY u.user_id
    FOR UPDATE
  `, [requireId(yearSectionId)]);
  for (const student of students) {
    const studentId = requireId(student.user_id);
    await connection.execute(
      'INSERT INTO enrollments (class_id, student_id) VALUES (?, ?)',
      [classId, studentId]
    );
    await insertAudit(
      connection,
      actorId,
      'class_member_added',
      `Enrolled user ${studentId} in class ${classId} from matching year and section`,
      ipAddress
    );
  }
}

async function createClass({
  yearSectionId, subject, teacherId, includeSectionStudents,
  studentIdNumbers, actorId, ipAddress,
}) {
  const db = getDb();
  const connection = await db.getConnection();
  try {
    await connection.beginTransaction();
    const [result] = await connection.execute(
      'INSERT INTO classes (year_section_id, teacher_id, subject) VALUES (?, ?, ?)',
      [requireId(yearSectionId), requireId(teacherId), subject]
    );
    const classId = String(result.insertId);
    await insertAudit(
      connection,
      actorId,
      'class_created',
      `Created class ${classId}: ${subject}`,
      ipAddress
    );
    await insertAudit(
      connection,
      actorId,
      'class_teacher_assigned',
      `Assigned user ${teacherId} as teacher of class ${classId}`,
      ipAddress
    );
    if (includeSectionStudents) {
      await enrollAllStudentsInYearSection(
        connection,
        classId,
        yearSectionId,
        actorId,
        ipAddress
      );
    }
    const report = await enrollStudentNumbers(
      connection, classId, parseStudentIdNumbers(studentIdNumbers), actorId, ipAddress
    );
    await connection.commit();
    return { id: classId, report };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function updateClass(id, { yearSectionId, subject, teacherId, actorId, ipAddress }) {
  const connection = await getDb().getConnection();
  try {
    await connection.beginTransaction();
    const classId = requireId(id);
    const [rows] = await connection.execute(
      'SELECT class_id, teacher_id, year_section_id, subject FROM classes WHERE class_id = ? FOR UPDATE',
      [classId]
    );
    if (!rows[0]) {
      await connection.rollback();
      return false;
    }
    await connection.execute(
      'UPDATE classes SET teacher_id = ?, year_section_id = ?, subject = ? WHERE class_id = ?',
      [requireId(teacherId), requireId(yearSectionId), subject, classId]
    );
    await insertAudit(
      connection,
      actorId,
      'class_updated',
      `Updated class ${classId}: ${subject}`,
      ipAddress
    );
    if (String(rows[0].teacher_id) !== String(teacherId)) {
      await insertAudit(
        connection,
        actorId,
        'class_teacher_changed',
        `Changed teacher for class ${classId} to user ${teacherId}`,
        ipAddress
      );
    }
    if (String(rows[0].year_section_id) !== String(yearSectionId)) {
      await insertAudit(
        connection,
        actorId,
        'class_year_section_changed',
        `Changed academic section for class ${classId}`,
        ipAddress
      );
    }
    await connection.commit();
    return true;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function deleteClass(id, { actorId, ipAddress }) {
  const connection = await getDb().getConnection();
  try {
    await connection.beginTransaction();
    const classId = requireId(id);
    const [classes] = await connection.execute(
      'SELECT class_id FROM classes WHERE class_id = ? FOR UPDATE',
      [classId]
    );
    if (!classes[0]) {
      await connection.rollback();
      return false;
    }
    const [enrollments] = await connection.execute(
      'SELECT student_id FROM enrollments WHERE class_id = ? FOR UPDATE',
      [classId]
    );
    for (const enrollment of enrollments) {
      await insertAudit(
        connection,
        actorId,
        'class_member_removed',
        `Removed user ${enrollment.student_id} from deleted class ${classId}`,
        ipAddress
      );
    }
    await connection.execute('DELETE FROM classes WHERE class_id = ?', [classId]);
    await insertAudit(
      connection,
      actorId,
      'class_deleted',
      `Deleted class ${classId}`,
      ipAddress
    );
    await connection.commit();
    return true;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function enrollStudentNumbersForClass(classId, rawStudentIds, { actorId, ipAddress }) {
  const connection = await getDb().getConnection();
  try {
    await connection.beginTransaction();
    const id = requireId(classId);
    const [classes] = await connection.execute(
      'SELECT class_id FROM classes WHERE class_id = ? FOR UPDATE',
      [id]
    );
    if (!classes[0]) throw Object.assign(new Error('Class not found'), { code: 'CLASS_NOT_FOUND' });
    const report = await enrollStudentNumbers(
      connection, id, parseStudentIdNumbers(rawStudentIds), actorId, ipAddress
    );
    await connection.commit();
    return report;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function unenrollStudent(classId, studentId, { actorId, ipAddress }) {
  const connection = await getDb().getConnection();
  try {
    await connection.beginTransaction();
    const [result] = await connection.execute(
      'DELETE FROM enrollments WHERE class_id = ? AND student_id = ?',
      [requireId(classId), requireId(studentId)]
    );
    if (!result.affectedRows) {
      await connection.rollback();
      return false;
    }
    await insertAudit(
      connection,
      actorId,
      'class_member_removed',
      `Removed user ${studentId} from class ${classId}`,
      ipAddress
    );
    await connection.commit();
    return true;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function insertAudit(connection, userId, eventType, description, ipAddress) {
  await connection.execute(`
    INSERT INTO audit_logs (user_id, event_type, description, ip_address)
    VALUES (?, ?, ?, ?)
  `, [
    requireId(userId),
    eventType,
    description.slice(0, 255),
    ipAddress ? String(ipAddress).slice(0, 45) : null,
  ]);
}

function legacyPasswordHash(passwordHash, salt) {
  if (!salt || typeof passwordHash !== 'string' || passwordHash.startsWith('$2')) {
    return passwordHash;
  }
  return `legacy$${Buffer.from(salt, 'utf8').toString('base64url')}$${passwordHash}`;
}

async function importLegacyUsers(users) {
  if (!Array.isArray(users)) throw new TypeError('Legacy users must be an array');
  for (const legacy of users) {
    const email = typeof legacy.email === 'string' ? legacy.email.trim().toLowerCase() : '';
    if (!email) throw new Error('Cannot import a legacy account without an email');
    if (await findUserByEmail(email)) continue;

    const role = VALID_ROLES.has(legacy.role) ? legacy.role : 'student';
    const passwordHash = legacyPasswordHash(legacy.passwordHash || legacy.password_hash, legacy.salt);
    if (typeof passwordHash !== 'string' || !passwordHash) {
      throw new Error(`Cannot import account ${email} without a password hash`);
    }
    await createUser({
      email,
      phone: legacy.phone || null,
      passwordHash,
      role,
      firstName: legacy.firstName || legacy.first_name || '',
      middleName: legacy.middleName || legacy.middle_name || '',
      lastName: legacy.lastName || legacy.last_name || '',
      studentId: legacy.studentId || legacy.school_id_number || null,
      yearSectionId: null,
    });
  }
}

module.exports = {
  initMySql,
  listCourseworkRecords,
  replaceCourseworkRecords,
  courseworkRecordCount,
  listUsers,
  findUserByEmail,
  findUserByIdentifier,
  findUserById,
  createUser,
  updateUserPassword,
  updateUserRole,
  updateUserStatus,
  updateUserProfile,
  deleteUser,
  recordLoginAttempt,
  recordAuditLog,
  listAcademicOptions,
  findOrCreateYearSection,
  yearSectionExists,
  academicNameExists,
  academicParentExists,
  saveAcademicEntity,
  deleteAcademicEntity,
  importLegacyUsers,
  findClass,
  countClassesForTeacher,
  listClasses,
  listClassMembers,
  isStudentEnrolled,
  createClass,
  updateClass,
  deleteClass,
  enrollStudentNumbersForClass,
  unenrollStudent,
};
